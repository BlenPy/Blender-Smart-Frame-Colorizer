import bpy
from bpy.props import (
    BoolProperty, EnumProperty, StringProperty,
    CollectionProperty, IntProperty,
    FloatVectorProperty, FloatProperty
)
from bpy.types import AddonPreferences, PropertyGroup, UIList

_NODE_CACHE = {
    'SHADER': None,
    'GEOMETRY': None,
    'COMPOSITOR': None,
    'GENERAL': [
        ('NodeFrame', "Frame", "Organizational Frame"),
        ('NodeReroute', "Reroute", "Reroute point"),
        ('NodeGroupInput', "Group Input", "Input for node groups"),
        ('NodeGroupOutput', "Group Output", "Output for node groups")
    ]
}

def get_nodes_by_base_class(base_class):
    items = []
    for name in dir(bpy.types):
        cls = getattr(bpy.types, name)
        if isinstance(cls, type) and issubclass(cls, base_class) and cls is not base_class:
            try: 
                items.append((cls.bl_rna.identifier, cls.bl_rna.name, ""))
            except AttributeError: 
                continue
    return sorted(items, key=lambda x: x[1])

def ensure_cache():
    if _NODE_CACHE['SHADER'] is None:
        _NODE_CACHE['SHADER'] = get_nodes_by_base_class(bpy.types.ShaderNode)
    if _NODE_CACHE['GEOMETRY'] is None:
        _NODE_CACHE['GEOMETRY'] = get_nodes_by_base_class(bpy.types.GeometryNode)
    if _NODE_CACHE['COMPOSITOR'] is None:
        _NODE_CACHE['COMPOSITOR'] = get_nodes_by_base_class(bpy.types.CompositorNode)

def get_shader_nodes(self, context):
    ensure_cache()
    return _NODE_CACHE['SHADER']

def get_geometry_nodes(self, context):
    ensure_cache()
    return _NODE_CACHE['GEOMETRY']

def get_compositor_nodes(self, context):
    ensure_cache()
    return _NODE_CACHE['COMPOSITOR']

def get_filtered_group_nodes(self, context):
    """
    Returns nodes based on the selected 'category' of the Member item.
    This prevents loading 500+ nodes into a single dropdown and includes NodeFrame.
    """
    ensure_cache()
    category = getattr(self, "category", "GENERAL")
    
    if category == 'SHADER':
        return _NODE_CACHE['SHADER']
    elif category == 'GEOMETRY':
        return _NODE_CACHE['GEOMETRY']
    elif category == 'COMPOSITOR':
        return _NODE_CACHE['COMPOSITOR']
    
    return _NODE_CACHE['GENERAL']

class SFC_NodeGroupMember(PropertyGroup):    
    category: EnumProperty(
        name="Category",
        items=[
            ('GENERAL', "General", "Frames, Reroutes, etc."),
            ('SHADER', "Shader", "Shader Nodes"),
            ('GEOMETRY', "Geometry", "Geometry Nodes"),
            ('COMPOSITOR', "Compositor", "Compositor Nodes"),
        ],
        default='GENERAL',
        description="Filter node types by editor/category"
    )
    
    node_type: EnumProperty(
        name="Node Type",
        items=get_filtered_group_nodes,
        description="The node type to include in this group"
    )

class SFC_NodeGroup(PropertyGroup):
    name: StringProperty(name="Group Name", default="New Group")
    members: CollectionProperty(type=SFC_NodeGroupMember)
    active_member_index: IntProperty(default=0)

class SFC_PaletteColorItem(PropertyGroup):
    color: FloatVectorProperty(name="Color", subtype='COLOR', size=3, min=0.0, max=1.0, default=(1.0, 1.0, 1.0), description="The color swatch")
    position: FloatProperty(name="Position", description="Position on the gradient (0-1)", default=0.0, min=0.0, max=1.0, subtype='FACTOR')
    weight: FloatProperty(name="Weight", description="Probability weight for this color in 'Weighted Random' mode (0-100%)", default=1.0, min=0.0, max=100.0)

class SFC_PaletteItem(PropertyGroup):
    name: StringProperty(name="Palette Name", default="New Palette", description="A unique name for this palette")
    sampling_mode: EnumProperty(name="Sampling Mode", items=[("UNIFORM", "Uniform Random", "Each color has an equal chance"), ("WEIGHTED", "Weighted Random", "Chance is based on color weight"), ("GRADIENT", "Gradient", "Interpolates colors like a Color Ramp"), ("SEQUENTIAL", "Sequential", "Cycles through colors in order")], default="UNIFORM", description="How colors are chosen from this palette")
    gradient_interpolation: EnumProperty(name="Interpolation", items=[('LINEAR', "Linear", "Linear interpolation"), ('EASE', "Ease", "Ease interpolation")], default="LINEAR", description="The interpolation method for 'Gradient' mode")
    colors: CollectionProperty(type=SFC_PaletteColorItem)
    active_color_index: IntProperty(default=0)

class SFC_BaseRuleItem(PropertyGroup):
    name: StringProperty(name="Name", default="New Rule")

    rule_type: EnumProperty(
        name="Rule Type", 
        items=[
            ('NODE_TYPE', "Node Type", "Match a specific node type"), 
            ('KEYWORD', "Keyword", "Match text in the frame label"),
            ('GROUP', "Node Group", "Match any node type defined in a custom group")
        ], 
        default='NODE_TYPE', 
        description="The type of condition to check for this rule"
    )
    
    keyword: StringProperty(name="Keyword", default="Keyword", description="The text to search for in a frame's label")
    
    node_group_name: StringProperty(name="Node Group", description="The name of the Node Group to use")

    mode: EnumProperty(name="Mode", items=[("SINGLE", "Single Color", ""), ("PALETTE", "Use Palette", "")], default="SINGLE", description="What to do when this rule is matched")
    color: FloatVectorProperty(name="Color", subtype='COLOR', size=3, min=0.0, max=1.0, default=(0.5, 0.5, 0.5), description="The color to apply")
    palette_name: StringProperty(name="Palette Name", description="The palette to use", default="")

class SFC_ShaderRuleItem(SFC_BaseRuleItem):
    node_type: EnumProperty(name="Node Type", items=get_shader_nodes, description="The node type to search for inside a frame")

class SFC_GeometryRuleItem(SFC_BaseRuleItem):
    node_type: EnumProperty(name="Node Type", items=get_geometry_nodes, description="The node type to search for inside a frame")

class SFC_CompositorRuleItem(SFC_BaseRuleItem):
    node_type: EnumProperty(name="Node Type", items=get_compositor_nodes, description="The node type to search for inside a frame")

def draw_rule_list_item(layout, item):
    if item.rule_type == 'NODE_TYPE':
        node_name = item.node_type
        node_class = getattr(bpy.types, item.node_type, None)
        if node_class:
            node_name = node_class.bl_rna.name
        layout.label(text=node_name, icon='NODE')
    elif item.rule_type == 'GROUP':
        layout.label(text=f"Group: {item.node_group_name}", icon='GROUP_VERTEX')
    else:
        layout.label(text=item.keyword, icon='FONT_DATA')

class SFC_OT_ClearNodeCache(bpy.types.Operator):
    bl_idname = "sfc.clear_node_cache"
    bl_label = "Refresh Node List"
    bl_description = "Clears the internal cache of Blender nodes. Use this if new node types are not showing up"

    def execute(self, context):
        global _NODE_CACHE
        _NODE_CACHE['SHADER'] = None
        _NODE_CACHE['GEOMETRY'] = None
        _NODE_CACHE['COMPOSITOR'] = None
        self.report({'INFO'}, "Node cache cleared. Lists will refresh on next use.")
        return {'FINISHED'}

class SFC_UL_PaletteColors(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        pal, sw = data, item
        row = layout.row()
        row.prop(sw, "color", text="")
        if pal.sampling_mode == "WEIGHTED": 
            row.prop(sw, "weight", text="")
        elif pal.sampling_mode == "GRADIENT": 
            row.prop(sw, "position", slider=True, text="")

class SFC_UL_ShaderRules(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        draw_rule_list_item(layout, item)

class SFC_UL_GeometryRules(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        draw_rule_list_item(layout, item)

class SFC_UL_CompositorRules(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        draw_rule_list_item(layout, item)

class SFC_UL_Palettes(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index): 
        layout.label(text=item.name, icon='GROUP_VCOL')

class SFC_UL_NodeGroups(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.label(text=item.name, icon='OUTLINER_COLLECTION')

class SFC_UL_NodeGroupMembers(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        icon_map = {
            'GENERAL': 'NODE', 
            'SHADER': 'SHADING_RENDERED', 
            'GEOMETRY': 'GEOMETRY_NODES', 
            'COMPOSITOR': 'NODE_COMPOSITING' 
        }
        ic = icon_map.get(item.category, 'NODE')
        
        ensure_cache()
        label = item.node_type
        
        found = False
        for cache_list in _NODE_CACHE.values():
            if cache_list is not None:
                for identifier, name, _ in cache_list:
                    if identifier == item.node_type:
                        label = name
                        found = True
                        break
            if found:
                break
                
        layout.label(text=label, icon=ic)

class SFC_Preferences(AddonPreferences):
    bl_idname = __name__.split(".")[0]

    active_tab: EnumProperty(
        items=[
            ('SETTINGS', "Settings", ""), 
            ('RULES', "Rules", ""), 
            ('PALETTES', "Palettes", ""),
            ('GROUPS', "Node Groups", "")
        ], 
        default='SETTINGS'
    )
    
    auto_color: BoolProperty(name="Auto Color", default=True)
    color_mode: EnumProperty(name="Color Mode", items=[("RANDOM", "Random", ""), ("RULES", "By Rules", "")], default="RULES")
    fallback_random: BoolProperty(name="Fallback to Random", default=True)
    json_path: StringProperty(name="Config File Path", subtype='FILE_PATH')
    
    palettes: CollectionProperty(type=SFC_PaletteItem)
    active_palette_index: IntProperty(default=0)
    
    node_groups: CollectionProperty(type=SFC_NodeGroup)
    active_node_group_index: IntProperty(default=0)
    
    active_rule_editor: EnumProperty(
        name="Active Rule Editor",
        items=[
            ('SHADER', "Shader", "Shader Node Editor Rules"),
            ('GEOMETRY', "Geometry", "Geometry Node Editor Rules"),
            ('COMPOSITOR', "Compositor", "Compositor Rules"),
        ],
        default='SHADER'
    )
    
    shader_rules: CollectionProperty(type=SFC_ShaderRuleItem)
    active_shader_rule_index: IntProperty(default=0)
    
    geometry_rules: CollectionProperty(type=SFC_GeometryRuleItem)
    active_geometry_rule_index: IntProperty(default=0)
    
    compositor_rules: CollectionProperty(type=SFC_CompositorRuleItem)
    active_compositor_rule_index: IntProperty(default=0)

    def draw_rule_editor_box(self, layout, rule):
        """Helper function to draw the 'Edit Rule' box."""
        box = layout.box()
        col = box.column()
        col.scale_y = 1.1
        
        col.label(text="Rule Type")
        col.prop(rule, "rule_type", text="")
        col.separator(factor=0.5)

        if rule.rule_type == 'NODE_TYPE':
            col.prop(rule, "node_type", text="")
        elif rule.rule_type == 'GROUP':
            col.prop_search(rule, "node_group_name", self, "node_groups", text="Group", icon='GROUP_VERTEX')
        else:
            col.prop(rule, "keyword", text="")
        
        col.separator(factor=0.5) 
        col.prop(rule, "mode", text="")
        
        col.separator(factor=0.5) 
        if rule.mode == 'SINGLE':
            col.prop(rule, "color", text="")
        else:
            col.prop_search(rule, "palette_name", self, "palettes", text="Palette")

    def draw_node_groups_tab(self, context, layout):
        col_main = layout.column()
        col_main.scale_y = 0.9

        row_main = col_main.split(factor=0.5)

        left_col = row_main.column()
        left_col.label(text="Node Groups")
        
        row_groups = left_col.row()
        row_groups.template_list("SFC_UL_NodeGroups", "", self, "node_groups", self, "active_node_group_index")
        
        col_group_btns = row_groups.column(align=True)
        col_group_btns.operator("sfc.add_node_group", icon="ADD", text="")
        col_group_btns.operator("sfc.remove_node_group", icon="REMOVE", text="")

        right_col = row_main.column()
        
        if 0 <= self.active_node_group_index < len(self.node_groups):
            group = self.node_groups[self.active_node_group_index]

            left_col.separator(factor=0.5)
            left_col.prop(group, "name", text="Group Name")
            
            right_col.label(text=f"Members of '{group.name}'")
            
            row_members = right_col.row()
            row_members.template_list("SFC_UL_NodeGroupMembers", "", group, "members", group, "active_member_index")
            
            col_mem_btns = row_members.column(align=True)
            col_mem_btns.operator("sfc.add_node_group_member", icon="ADD", text="")
            col_mem_btns.operator("sfc.remove_node_group_member", icon="REMOVE", text="")
            
            if 0 <= group.active_member_index < len(group.members):
                right_col.separator(factor=0.5)
                member = group.members[group.active_member_index]
                
                right_col.prop(member, "category", text="Category")
                right_col.separator(factor=1.0)
                right_col.prop(member, "node_type", text="Node Type")

    def draw_rules_tab(self, context, layout):
        row = layout.row()
        row.prop(self, "active_rule_editor", expand=True)
        layout.separator(factor=0.5)
        
        col = layout.column()
        col.scale_y = 1.1
        
        rule_list = None
        index = None
        list_name = ""
        ui_list_name = ""
        
        if self.active_rule_editor == 'SHADER':
            rule_list = self.shader_rules
            list_name = "shader_rules"
            index = "active_shader_rule_index"
            ui_list_name = "SFC_UL_ShaderRules"
        elif self.active_rule_editor == 'GEOMETRY':
            rule_list = self.geometry_rules
            list_name = "geometry_rules"
            index = "active_geometry_rule_index"
            ui_list_name = "SFC_UL_GeometryRules"
        elif self.active_rule_editor == 'COMPOSITOR':
            rule_list = self.compositor_rules
            list_name = "compositor_rules"
            index = "active_compositor_rule_index"
            ui_list_name = "SFC_UL_CompositorRules"

        if rule_list is None: return

        col.label(text=f"{self.active_rule_editor.capitalize()} Rules")
        row = col.row()
        row.template_list(ui_list_name, "", self, list_name, self, index)
        
        col_buttons = row.column(align=True)
        col_buttons.operator("sfc.add_rule", icon="ADD", text="")
        col_buttons.operator("sfc.remove_rule", icon="REMOVE", text="")
        col_buttons.separator(factor=0.5)
        op_up = col_buttons.operator("sfc.move_rule", icon='TRIA_UP', text="")
        op_up.direction = 'UP'
        op_down = col_buttons.operator("sfc.move_rule", icon='TRIA_DOWN', text="")
        op_down.direction = 'DOWN'
        
        col.separator(factor=0.5)
        active_index_val = getattr(self, index, 0)
        if 0 <= active_index_val < len(rule_list):
            active_rule = rule_list[active_index_val]
            self.draw_rule_editor_box(col, active_rule)

    def draw_palettes_tab(self, context, layout):
        col_main = layout.column()
        col_main.scale_y = 0.9
        col_main.label(text="Palettes")
        
        row_list = col_main.row()
        row_list.template_list("SFC_UL_Palettes", "", self, "palettes", self, "active_palette_index")
        
        col_buttons_list = row_list.column(align=True)
        col_buttons_list.operator("sfc.add_palette", icon="ADD", text="")
        col_buttons_list.operator("sfc.remove_palette", icon="REMOVE", text="")

        if not self.palettes or not (0 <= self.active_palette_index < len(self.palettes)): return
        
        col_main.separator(factor=0.5)
        pal = self.palettes[self.active_palette_index]
        split_editor = col_main.split(factor=0.5)
        
        left_col = split_editor.column()
        left_col.label(text="Edit Palette")
        left_col.prop(pal, "name", text="")
        left_col.separator(factor=0.5) 
        left_col.prop(pal, "sampling_mode", text="")
        left_col.separator(factor=0.5) 
        
        if pal.sampling_mode == "GRADIENT": 
            left_col.prop(pal, "gradient_interpolation", text="")
        elif pal.sampling_mode == "WEIGHTED":
            left_col.separator(factor=0.5) 
            total = sum(c.weight for c in pal.colors)
            icon = 'CHECKMARK' if abs(total - 100.0) < 0.01 else 'ERROR'
            left_col.label(text=f"Total Weight: {total:.1f}/100", icon=icon)

        right_col = split_editor.column()
        right_col.label(text="Colors")
        row_colors = right_col.row()
        row_colors.template_list("SFC_UL_PaletteColors", "", pal, "colors", pal, "active_color_index")
        
        col_color_buttons = row_colors.column(align=True)
        col_color_buttons.operator("sfc.add_palette_color", icon="ADD", text="")
        
        op_rem = col_color_buttons.operator("sfc.remove_palette_color", icon="REMOVE", text="")
        op_rem.index = pal.active_color_index
        
        col_color_buttons.separator(factor=0.5)
        row_up = col_color_buttons.row(align=True)
        row_up.enabled = pal.active_color_index > 0
        op_up = row_up.operator("sfc.move_palette_color", icon='TRIA_UP', text="")
        op_up.direction = 'UP'
        
        row_down = col_color_buttons.row(align=True)
        row_down.enabled = pal.active_color_index < len(pal.colors) - 1
        op_down = row_down.operator("sfc.move_palette_color", icon='TRIA_DOWN', text="")
        op_down.direction = 'DOWN'

    def draw_settings_tab(self, context, layout):
        col = layout.column()
        col.scale_y = 1.1
        col.label(text="General Behavior", icon="PRESET")
        col.prop(self, "auto_color")
        
        if self.color_mode == "RULES": 
            col.prop(self, "fallback_random")
            
        col.separator(factor=0.5)
        col.label(text="Config Import/Export", icon="FILE_FOLDER")
        
        col_config = col.column()
        col_config.enabled = self.color_mode == 'RULES' 
        col_config.prop(self, "json_path", text="")
        
        row = col_config.row(align=True)
        row.operator("sfc.load_config", text="Load", icon="FILE_REFRESH")
        row.operator("sfc.save_config", text="Save", icon="FILE_TICK")

        col.separator(factor=1.0)
        col.label(text="Maintenance", icon="FILE_REFRESH")
        col.operator("sfc.clear_node_cache", icon="FILE_REFRESH")

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "color_mode")
        layout.separator(factor=0.5)
        
        row = layout.row()
        row.prop(self, "active_tab", expand=True)
        main_col = layout.column()
        
        is_rules_mode = self.color_mode == 'RULES'
        
        if self.active_tab == 'RULES':
            if not is_rules_mode: 
                main_col.label(text="Rules are only available in 'By Rules' mode.", icon='INFO')
            else: 
                self.draw_rules_tab(context, main_col)
        elif self.active_tab == 'PALETTES':
            if not is_rules_mode: 
                main_col.label(text="Palettes are only available in 'By Rules' mode.", icon='INFO')
            else: 
                self.draw_palettes_tab(context, main_col)
        elif self.active_tab == 'GROUPS':
            if not is_rules_mode: 
                main_col.label(text="Groups are only available in 'By Rules' mode.", icon='INFO')
            else: 
                self.draw_node_groups_tab(context, main_col)
        elif self.active_tab == 'SETTINGS':
            self.draw_settings_tab(context, main_col)

classes = (
    SFC_NodeGroupMember,
    SFC_NodeGroup,
    
    SFC_PaletteColorItem, 
    SFC_PaletteItem, 

    SFC_BaseRuleItem,
    SFC_ShaderRuleItem,
    SFC_GeometryRuleItem,
    SFC_CompositorRuleItem,

    SFC_UL_PaletteColors, 
    SFC_UL_ShaderRules,
    SFC_UL_GeometryRules,
    SFC_UL_CompositorRules,
    SFC_UL_Palettes,
    SFC_UL_NodeGroups,
    SFC_UL_NodeGroupMembers,
    SFC_OT_ClearNodeCache,

    SFC_Preferences,
)

def register():
    for cls in classes: bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        try: bpy.utils.unregister_class(cls)
        except RuntimeError: pass