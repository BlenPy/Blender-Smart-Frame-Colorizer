import json
import bpy

def export_config(filepath, prefs):
    data = {
        "palettes": [], 
        "node_groups": [], 
        "editor_rule_sets": []
    }

    for p in prefs.palettes:
        pd = {"name": p.name, "sampling_mode": p.sampling_mode, "gradient_interpolation": p.gradient_interpolation, "colors": []}
        for c in p.colors: pd["colors"].append({"color": list(c.color), "weight": c.weight, "position": c.position})
        data["palettes"].append(pd)

    for g in prefs.node_groups:
        gd = {
            "name": g.name,
            "members": []
        }
        for m in g.members:
            gd["members"].append({
                "type": m.node_type,
                "category": m.category
            })
        data["node_groups"].append(gd)
        
    for set_name, rule_list in [("SHADER", prefs.shader_rules), ("GEOMETRY", prefs.geometry_rules), ("COMPOSITOR", prefs.compositor_rules)]:
        rule_set_data = {"name": set_name, "rules": []}
        for r in rule_list:
            rule_set_data["rules"].append({
                "rule_type": r.rule_type, "keyword": r.keyword, "node_type": r.node_type,
                "node_group_name": r.node_group_name, "mode": r.mode,
                "color": list(r.color), "palette_name": r.palette_name
            })
        data["editor_rule_sets"].append(rule_set_data)
        
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

def import_config(filepath, prefs):
    import os
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Config file not found at {filepath}")
    
    try:
        with open(filepath, "r", encoding="utf-8") as f: 
            data = json.load(f)
    except json.JSONDecodeError:
        raise Exception("Failed to parse JSON: File is corrupted or improperly formatted.")

    prefs.palettes.clear()
    prefs.node_groups.clear()
    prefs.shader_rules.clear()
    prefs.geometry_rules.clear()
    prefs.compositor_rules.clear()

    for pd in data.get("palettes", []):
        p = prefs.palettes.add(); p.name = pd.get("name", "New"); p.sampling_mode = pd.get("sampling_mode", "UNIFORM")
        for cd in pd.get("colors", []):
            c = p.colors.add(); c.color = tuple(cd.get("color", [1,1,1])); c.weight = cd.get("weight", 1); c.position = cd.get("position", 0)

    from . import preferences
    preferences.ensure_cache()

    for gd in data.get("node_groups", []):
        g = prefs.node_groups.add()
        g.name = gd.get("name", "New Group")
        
        raw_members = gd.get("members", [])
        for item in raw_members:
            m = g.members.add()
            if isinstance(item, dict):
                m.category = item.get("category", "GENERAL")
                m.node_type = item.get("type", "NodeFrame")
            else:
                m.category = 'GENERAL'
                m.node_type = str(item)
                
    for rule_set in data.get("editor_rule_sets", []):
        target_list = getattr(prefs, f"{rule_set.get('name').lower()}_rules", None)
        if not target_list: continue
        for rd in rule_set.get("rules", []):
            r = target_list.add(); r.mode = rd.get("mode", "SINGLE"); r.color = tuple(rd.get("color", [0.5,0.5,0.5])); r.palette_name = rd.get("palette_name", "")
            r.rule_type = rd.get("rule_type", "NODE_TYPE")
            if r.rule_type == "NODE_TYPE": r.node_type = rd.get("node_type", "")
            elif r.rule_type == "GROUP": r.node_group_name = rd.get("node_group_name", "")
            else: r.keyword = rd.get("keyword", "")