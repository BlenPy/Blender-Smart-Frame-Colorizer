import bpy

addon_keymaps = []

def register_keymap():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if not kc: return

    # Keymaps for the Node Editor
    km_node = kc.keymaps.new(name='Node Editor', space_type='NODE_EDITOR')
    shortcuts = {
        'sfc.apply_quick_color': 'Q',
        'sfc.apply_color_selected_frames': 'U',
        'sfc.apply_color_all_frames': 'A',
        'sfc.reset_color_selected_frames': 'R',
        'sfc.reset_color_all_frames': 'X',
    }
    
    for operator_idname, key in shortcuts.items():
        kmi = km_node.keymap_items.new(operator_idname, key, 'PRESS', shift=True, alt=True)
        addon_keymaps.append((km_node, kmi))

def unregister_keymap():
    for km, kmi in addon_keymaps:
        try: km.keymap_items.remove(kmi)
        except: pass
    addon_keymaps.clear()

classes = ()

def register():
    register_keymap()

def unregister():
    unregister_keymap()