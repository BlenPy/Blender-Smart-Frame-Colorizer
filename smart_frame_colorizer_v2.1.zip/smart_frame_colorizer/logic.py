import bpy
import random
from . import storage

_sequential_counters = {}

def get_prefs(context):
    return context.preferences.addons[__package__].preferences

def get_color_from_weighted(pal, rng):
    if not pal.colors: return (0.8, 0.8, 0.8)
    total_weight = sum(c.weight for c in pal.colors)
    if total_weight <= 0: return tuple(rng.choice(pal.colors).color)
    rand_val = rng.uniform(0, total_weight)
    current_weight = 0
    for c in pal.colors:
        current_weight += c.weight
        if rand_val <= current_weight: return tuple(c.color)
    return tuple(pal.colors[-1].color)

def get_color_from_sequential(pal):
    if not pal.colors: return (0.8, 0.8, 0.8)
    palette_key = pal.name
    current_index = _sequential_counters.get(palette_key, 0)
    chosen_color = tuple(pal.colors[current_index].color)
    _sequential_counters[palette_key] = (current_index + 1) % len(pal.colors)
    return chosen_color

def get_color_from_uniform(pal, rng):
    if not pal.colors: return (0.8, 0.8, 0.8)
    return tuple(rng.choice(pal.colors).color)

def _lerp(a, b, t): return a + t * (b - a)
def _ease(t): return t * t * (3.0 - 2.0 * t)

def _interpolate_color(c1, c2, factor, mode):
    if mode == 'EASE': factor = _ease(factor)
    return (_lerp(c1[0], c2[0], factor), _lerp(c1[1], c2[1], factor), _lerp(c1[2], c2[2], factor))

def get_color_from_gradient(pal, rng):
    if not pal.colors: return (0.8, 0.8, 0.8)
    if len(pal.colors) == 1: return tuple(pal.colors[0].color)
    stops = sorted(pal.colors, key=lambda c: c.position)
    fac = rng.random() # Use the stable RNG
    if fac <= stops[0].position: return tuple(stops[0].color)
    if fac >= stops[-1].position: return tuple(stops[-1].color)
    stop_before, stop_after = stops[0], stops[-1]
    for i in range(len(stops) - 1):
        if stops[i].position <= fac and stops[i+1].position >= fac:
            stop_before, stop_after = stops[i], stops[i+1]
            break
    dist = stop_after.position - stop_before.position
    local_fac = (fac - stop_before.position) / dist if dist > 0.0001 else 0.0
    return _interpolate_color(stop_before.color, stop_after.color, local_fac, pal.gradient_interpolation)

def pick_color_for_frame(frame_node, prefs, editor_context):
    rng = random.Random(frame_node.name)
    
    rule_list = None
    if editor_context == 'SHADER':
        rule_list = prefs.shader_rules
    elif editor_context == 'GEOMETRY':
        rule_list = prefs.geometry_rules
    elif editor_context == 'COMPOSITOR':
        rule_list = prefs.compositor_rules
    
    if not rule_list:
        return None 

    def get_color_from_rule_match(rule):
        if rule.mode == "SINGLE":
            return tuple(rule.color)
        
        pal = storage.get_palette_by_name(prefs, rule.palette_name)
        if pal:
            mode_map = {
                'GRADIENT': get_color_from_gradient,
                'WEIGHTED': get_color_from_weighted,
                'UNIFORM': get_color_from_uniform,
            }

            if pal.sampling_mode == 'SEQUENTIAL':
                return get_color_from_sequential(pal)
            
            sample_func = mode_map.get(pal.sampling_mode, get_color_from_uniform)
            return sample_func(pal, rng)
        
        return (0.8, 0.8, 0.8) 

    frame_children = []
    tree = frame_node.id_data
    if tree:
        for child in tree.nodes:
            if getattr(child, "parent", None) == frame_node:
                frame_children.append(child)

    for rule in rule_list:
        if rule.rule_type == 'KEYWORD':
            label = (frame_node.label or "").lower()
            if rule.keyword and rule.keyword.lower() in label:
                return get_color_from_rule_match(rule) 
        
        elif rule.rule_type == 'NODE_TYPE':
            if rule.node_type:
                for child in frame_children:
                    if child.bl_rna.identifier == rule.node_type:
                        return get_color_from_rule_match(rule)

        elif rule.rule_type == 'GROUP':
            target_group = None
            for g in prefs.node_groups:
                if g.name == rule.node_group_name:
                    target_group = g
                    break
            
            if target_group:
                member_types = {m.node_type for m in target_group.members}
                
                for child in frame_children:
                    if child.bl_rna.identifier in member_types:
                        return get_color_from_rule_match(rule)

    return None

def apply_color_to_frame(frame_node, col):
    if not frame_node.use_custom_color or any(abs(c1 - c2) > 0.001 for c1, c2 in zip(frame_node.color, col)):
        frame_node.use_custom_color = True
        frame_node.color = col

def on_node_tree_update(scene):
    prefs = get_prefs(bpy.context)
    if not prefs.auto_color: return

    for area in bpy.context.window.screen.areas:
        if area.type != "NODE_EDITOR": continue
        space = area.spaces.active
        if not space.node_tree: continue
        
        tree_type = space.node_tree.bl_idname
        editor_context = None
        if tree_type == 'ShaderNodeTree':
            editor_context = 'SHADER'
        elif tree_type == 'GeometryNodeTree':
            editor_context = 'GEOMETRY'
        elif tree_type == 'CompositorNodeTree':
            editor_context = 'COMPOSITOR'
        
        if not editor_context:
            continue
            
        for node in space.node_tree.nodes:
            if node.bl_idname == "NodeFrame":
                if prefs.color_mode == "RULES":
                    target_color = pick_color_for_frame(node, prefs, editor_context)
                    if target_color:
                        apply_color_to_frame(node, target_color)
                    elif prefs.fallback_random and not node.use_custom_color:
                        apply_color_to_frame(node, (random.random(), random.random(), random.random()))
                
                elif prefs.color_mode == "RANDOM" and not node.use_custom_color:
                    apply_color_to_frame(node, (random.random(), random.random(), random.random()))

_registered_handlers = []
def register_handlers():
    if on_node_tree_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(on_node_tree_update)
        _registered_handlers.append(on_node_tree_update)

def unregister_handlers():
    for h in _registered_handlers:
        if h in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(h)
    _registered_handlers.clear()

def register(): pass
def unregister(): pass