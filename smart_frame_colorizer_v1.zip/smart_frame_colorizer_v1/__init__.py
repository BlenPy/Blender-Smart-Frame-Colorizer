# __init__.py

bl_info = {
    "name":        "Smart Frame Colorizer",
    "author":      "BlenPy",
    "version":     (0, 1, 0),
    "blender":     (4, 5, 0),
    "description": "Automatically color Frame nodes using rules, palettes, and shortcuts.",
    "category":    "Node",
}

import bpy

from . import (
    preferences, operators, json_io,
    logic, ui, storage, dev_tools, keymap,
)

modules = (
    preferences, operators, json_io,
    logic, ui, storage, dev_tools, keymap,
)

def register():
    for mod in modules:
        if hasattr(mod, "register"):
            mod.register()
    
    logic.register_handlers()

def unregister():
    logic.unregister_handlers()
    
    for mod in reversed(modules):
        if hasattr(mod, "unregister"):
            mod.unregister()