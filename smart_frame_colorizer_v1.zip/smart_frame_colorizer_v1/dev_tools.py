# dev_tools.py

import bpy
from bpy.types import Operator
from . import logic

def get_prefs(context):
    """Helper function to get the addon's preferences."""
    return context.preferences.addons[__package__].preferences

class SFC_OT_TestPalette(Operator):
    """Generates a sample image to visualize the color distribution of the active palette."""
    bl_idname = "sfc.test_palette"
    bl_label = "Test Palette Distribution"
    bl_description = "Generate a sample image to visualize the color distribution of this palette"

    @classmethod
    def poll(cls, context):
        prefs = get_prefs(context)
        return 0 <= prefs.active_palette_index < len(prefs.palettes)

    def execute(self, context):
        prefs = get_prefs(context)
        pal = prefs.palettes[prefs.active_palette_index]
        
        img_size, tile_size = 256, 16
        tiles_per_row = img_size // tile_size
        num_tiles = tiles_per_row * tiles_per_row
        
        image_name = f"Test_{pal.name}"
        if image_name in bpy.data.images:
            bpy.data.images.remove(bpy.data.images[image_name])
        img = bpy.data.images.new(image_name, width=img_size, height=img_size)
        
        pixels = [0.0] * (img_size * img_size * 4)

        for i in range(num_tiles):
            color_rgb = (0, 0, 0)
            if pal.sampling_mode == 'GRADIENT': color_rgb = logic.get_color_from_gradient(pal)
            elif pal.sampling_mode == 'WEIGHTED': color_rgb = logic.get_color_from_weighted(pal)
            elif pal.sampling_mode == 'SEQUENTIAL': color_rgb = logic.get_color_from_sequential(pal)
            else: color_rgb = logic.get_color_from_uniform(pal)
            
            color_rgba = (*color_rgb, 1.0)
            tile_x, tile_y = (i % tiles_per_row) * tile_size, (i // tiles_per_row) * tile_size

            for y in range(tile_size):
                for x in range(tile_size):
                    px_index = ((tile_y + y) * img_size + (tile_x + x)) * 4
                    pixels[px_index : px_index + 4] = color_rgba
        
        img.pixels = pixels
        self.report({'INFO'}, f"Test image '{image_name}' created in Image Editor.")
        return {'FINISHED'}

# --- Registration ---

classes = (
    SFC_OT_TestPalette,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass