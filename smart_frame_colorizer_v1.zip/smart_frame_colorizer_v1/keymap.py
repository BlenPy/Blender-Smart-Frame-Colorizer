# keymap.py

import bpy
from bpy.types import Operator

def get_prefs(context):
    """Helper function to get the addon's preferences."""
    return context.preferences.addons[__package__].preferences

class SFC_OT_ToggleDeveloperMode(Operator):
    """Toggles the developer tools for advanced debugging and testing."""
    bl_idname = "sfc.toggle_developer_mode"
    bl_label = "Toggle Developer Mode"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        prefs = get_prefs(context)
        prefs.developer_mode = not prefs.developer_mode
        status = "Enabled" if prefs.developer_mode else "Disabled"
        self.report({'INFO'}, f"SFC Developer Mode: {status}")
        return {'FINISHED'}

# --- Keymap Registration ---
addon_keymaps = []

def register_keymap():
    """Creates and registers all keyboard shortcuts for the addon."""
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon

    if not kc: return

    # 1. Keymap for global window actions (Developer Mode Toggle)
    km_window = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi_dev = km_window.keymap_items.new(
        SFC_OT_ToggleDeveloperMode.bl_idname, 
        'D', 'PRESS', ctrl=True, alt=True
    )
    addon_keymaps.append((km_window, kmi_dev))

    # 2. Keymap for actions specific to the Node Editor
    km_node = kc.keymaps.new(name='Node Editor', space_type='NODE_EDITOR')
    
    shortcuts = {
        'sfc.apply_quick_color': 'Q',
        'sfc.apply_color_selected_frames': 'U',
        'sfc.apply_color_all_frames': 'A',
        'sfc.reset_color_selected_frames': 'R',
        'sfc.reset_color_all_frames': 'X',
    }
    
    for operator_idname, key in shortcuts.items():
        # CHANGED: Shortcut is now Shift+Alt+KEY
        kmi = km_node.keymap_items.new(
            operator_idname, key, 'PRESS', 
            shift=True, alt=True
        )
        addon_keymaps.append((km_node, kmi))

def unregister_keymap():
    """Removes all keyboard shortcuts registered by this addon."""
    for km, kmi in addon_keymaps:
        try: km.keymap_items.remove(kmi)
        except: pass
    addon_keymaps.clear()

# --- Main Module Registration ---
classes = (
    SFC_OT_ToggleDeveloperMode,
)

def register():
    for cls in classes: bpy.utils.register_class(cls)
    register_keymap()

def unregister():
    unregister_keymap()
    for cls in reversed(classes):
        try: bpy.utils.unregister_class(cls)
        except RuntimeError: pass