# preferences.py

import bpy
from bpy.props import (
    BoolProperty, EnumProperty, StringProperty,
    CollectionProperty, IntProperty,
    FloatVectorProperty, FloatProperty
)
from bpy.types import AddonPreferences, PropertyGroup, UIList

def get_all_shader_node_types(self, context):
    items = []
    for name in dir(bpy.types):
        cls = getattr(bpy.types, name)
        if isinstance(cls, type) and issubclass(cls, bpy.types.ShaderNode) and cls is not bpy.types.ShaderNode:
            try: items.append((cls.bl_rna.identifier, cls.bl_rna.name, ""))
            except AttributeError: continue
    return sorted(items, key=lambda x: x[1])

class SFC_PaletteColorItem(PropertyGroup):
    color: FloatVectorProperty(name="Color", subtype='COLOR', size=3, min=0.0, max=1.0, default=(1.0, 1.0, 1.0), description="The color swatch")
    position: FloatProperty(name="Position", description="Position on the gradient (0-1)", default=0.0, min=0.0, max=1.0, subtype='FACTOR')
    weight: FloatProperty(name="Weight", description="Probability weight for this color in 'Weighted Random' mode (0-100%)", default=1.0, min=0.0, max=100.0)

class SFC_PaletteItem(PropertyGroup):
    name: StringProperty(name="Palette Name", default="New Palette", description="A unique name for this palette")
    sampling_mode: EnumProperty(name="Sampling Mode", items=[("UNIFORM", "Uniform Random", "Each color has an equal chance"), ("WEIGHTED", "Weighted Random", "Chance is based on color weight"), ("GRADIENT", "Gradient", "Interpolates colors like a Color Ramp"), ("SEQUENTIAL", "Sequential", "Cycles through colors in order")], default="UNIFORM", description="How colors are chosen from this palette")
    gradient_interpolation: EnumProperty(name="Interpolation", items=[('LINEAR', "Linear", "Linear interpolation between color stops"), ('EASE', "Ease", "Ease interpolation between color stops"), ('CARDINAL', "Cardinal", "Cardinal interpolation (not yet implemented)"), ('BSPLINE', "B-Spline", "B-Spline interpolation (not yet implemented)")], default="LINEAR", description="The interpolation method for 'Gradient' mode")
    colors: CollectionProperty(type=SFC_PaletteColorItem)
    active_color_index: IntProperty(default=0)

class SFC_NodeRuleItem(PropertyGroup):
    node_type: EnumProperty(name="Node Type", items=get_all_shader_node_types, description="This rule will trigger if a frame contains a node of this type")
    mode: EnumProperty(name="Mode", items=[("SINGLE", "Single Color", "Apply a single color"), ("PALETTE", "Use Palette", "Pick a color from a palette")], default="SINGLE", description="What to do when this rule is matched")
    color: FloatVectorProperty(name="Color", subtype='COLOR', size=3, min=0.0, max=1.0, default=(0.5, 0.5, 0.5), description="The color to apply in 'Single Color' mode")
    palette_name: StringProperty(name="Palette Name", default="", description="The name of the palette to use in 'Use Palette' mode")

class SFC_KeywordRuleItem(PropertyGroup):
    label: StringProperty(name="Label Keyword", default="AO", description="This rule will trigger if a frame's label contains this text (case-insensitive)")
    mode: EnumProperty(name="Mode", items=[("SINGLE", "Single Color", "Apply a single color"), ("PALETTE", "Use Palette", "Pick a color from a palette")], default="SINGLE", description="What to do when this rule is matched")
    color: FloatVectorProperty(name="Color", subtype='COLOR', size=3, min=0.0, max=1.0, default=(0.3, 0.6, 1.0), description="The color to apply in 'Single Color' mode")
    palette_name: StringProperty(name="Palette Name", default="", description="The name of the palette to use in 'Use Palette' mode")

class SFC_UL_NodeRules(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index): layout.label(text=item.node_type.replace("ShaderNode", ""), icon='NODE')
class SFC_UL_KeywordRules(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index): layout.label(text=item.label, icon='FONT_DATA')
class SFC_UL_Palettes(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index): layout.label(text=item.name, icon='GROUP_VCOL')

class SFC_Preferences(AddonPreferences):
    bl_idname = __name__.split(".")[0]

    auto_color: BoolProperty(name="Auto Color on Frame Creation", description="Automatically color frames when they are created", default=True)
    color_mode: EnumProperty(name="Color Mode", items=[("RANDOM", "Random", "Assign random colors"), ("RULES", "By Rules", "Use custom rules and palettes")], default="RANDOM", description="The primary method for coloring frames")
    fallback_random: BoolProperty(name="Fallback to Random", description="If no rule matches in 'By Rules' mode, assign a random color", default=True)
    json_path: StringProperty(name="Config File Path", subtype='FILE_PATH', default="", description="Path to the JSON file for importing/exporting rules and palettes")
    developer_mode: BoolProperty(name="Enable Developer Tools", description="Show advanced tools for testing and debugging. Toggle with Ctrl+Alt+D", default=False)
    
    palettes: CollectionProperty(type=SFC_PaletteItem)
    active_palette_index: IntProperty(default=0)
    node_rules: CollectionProperty(type=SFC_NodeRuleItem)
    active_node_rule_index: IntProperty(default=0)
    keyword_rules: CollectionProperty(type=SFC_KeywordRuleItem)
    active_keyword_rule_index: IntProperty(default=0)

    def draw(self, context):
        layout = self.layout; layout.use_property_split = True; layout.use_property_decorate = False
        box = layout.box(); box.label(text="Coloring Behavior", icon="PRESET")
        box.prop(self, "auto_color"); box.prop(self, "color_mode")
        if self.color_mode == "RULES": box.prop(self, "fallback_random")

        if self.color_mode == "RULES":
            box = layout.box(); box.label(text="Config Import/Export", icon="FILE_FOLDER")
            box.prop(self, "json_path")
            row = box.row(align=True); row.operator("sfc.load_config", text="Load", icon="FILE_REFRESH"); row.operator("sfc.save_config", text="Save", icon="FILE_TICK")
            
            box = layout.box(); box.label(text="Node-Based Rules", icon="NODE")
            row = box.row(); row.template_list("SFC_UL_NodeRules", "", self, "node_rules", self, "active_node_rule_index")
            col = row.column(align=True); col.operator("sfc.add_node_rule", icon="ADD", text=""); col.operator("sfc.remove_node_rule", icon="REMOVE", text="")
            if self.node_rules:
                rule = self.node_rules[self.active_node_rule_index]; box.prop(rule, "node_type"); box.prop(rule, "mode")
                if rule.mode == "SINGLE": box.prop(rule, "color")
                else: box.prop(rule, "palette_name")

            box = layout.box(); box.label(text="Keyword-Based Rules", icon="FONT_DATA")
            row = box.row(); row.template_list("SFC_UL_KeywordRules", "", self, "keyword_rules", self, "active_keyword_rule_index")
            col = row.column(align=True); col.operator("sfc.add_keyword_rule", icon="ADD", text=""); col.operator("sfc.remove_keyword_rule", icon="REMOVE", text="")
            if self.keyword_rules:
                rule = self.keyword_rules[self.active_keyword_rule_index]; box.prop(rule, "label"); box.prop(rule, "mode")
                if rule.mode == "SINGLE": box.prop(rule, "color")
                else: box.prop(rule, "palette_name")

        if self.color_mode != "RANDOM":
            box = layout.box(); box.label(text="Palettes", icon="GROUP_VCOL")
            row = box.row(align=True); row.template_list("SFC_UL_Palettes", "", self, "palettes", self, "active_palette_index")
            col = row.column(align=True); col.operator("sfc.add_palette", icon="ADD", text=""); col.operator("sfc.remove_palette", icon="REMOVE", text="")
            sort_col = col.column(align=True); sort_col.active = False
            if self.palettes and 0 <= self.active_palette_index < len(self.palettes):
                if self.palettes[self.active_palette_index].sampling_mode == "GRADIENT": sort_col.active = True
            sort_col.operator("sfc.sort_palette_colors", icon='SORTALPHA', text="")

            if self.palettes:
                pal = self.palettes[self.active_palette_index]; box.prop(pal, "name"); box.prop(pal, "sampling_mode")
                if pal.sampling_mode == "GRADIENT": box.prop(pal, "gradient_interpolation")
                elif pal.sampling_mode == "WEIGHTED":
                    total = sum(c.weight for c in pal.colors); icon = 'CHECKMARK' if abs(total - 100.0) < 0.01 else 'ERROR'
                    box.label(text=f"Total Weight: {total:.1f}/100", icon=icon)
                header = box.row(align=True); header.label(text="Color")
                if pal.sampling_mode == "WEIGHTED": header.label(text="Weight %")
                elif pal.sampling_mode == "GRADIENT": header.label(text="Position")
                header.label(text="")
                for i, sw in enumerate(pal.colors):
                    row = box.row(align=True); row.prop(sw, "color", text="")
                    if pal.sampling_mode == "WEIGHTED": row.prop(sw, "weight", text="")
                    elif pal.sampling_mode == "GRADIENT": row.prop(sw, "position", slider=True, text="")
                    op = row.operator("sfc.remove_palette_color", icon="REMOVE", text=""); op.index = i
                box.operator("sfc.add_palette_color", icon="ADD", text="Add Swatch")
                if self.developer_mode:
                    dev_box = box.box(); dev_box.label(text="Developer Tools", icon="SETTINGS")
                    row = dev_box.row(); row.enabled = bool(pal.colors)
                    row.operator("sfc.test_palette", text="Test Distribution", icon='IMAGE_DATA')

classes = (
    SFC_PaletteColorItem, SFC_PaletteItem, SFC_NodeRuleItem, SFC_KeywordRuleItem,
    SFC_UL_NodeRules, SFC_UL_KeywordRules, SFC_UL_Palettes, SFC_Preferences,
)

def register():
    for cls in classes: bpy.utils.register_class(cls)
def unregister():
    for cls in reversed(classes):
        try: bpy.utils.unregister_class(cls)
        except RuntimeError: pass