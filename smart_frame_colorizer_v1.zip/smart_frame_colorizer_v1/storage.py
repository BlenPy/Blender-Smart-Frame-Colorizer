from .preferences import SFC_PaletteItem, SFC_NodeRuleItem, SFC_KeywordRuleItem

def get_palette_by_name(prefs, name):
    for p in prefs.palettes:
        if p.name == name:
            return p
    return None

def get_node_rule_by_type(prefs, t):
    for nr in prefs.node_rules:
        if nr.node_type == t:
            return nr
    return None

def get_keyword_rule_by_label(prefs, lab):
    lab=lab.lower()
    for kr in prefs.keyword_rules:
        if kr.label.lower() == lab:
            return kr
    return None