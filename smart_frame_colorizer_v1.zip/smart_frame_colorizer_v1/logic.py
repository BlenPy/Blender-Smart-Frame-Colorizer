# logic.py

import bpy
import random
from . import storage

# A persistent dictionary to store counters for the 'Sequential' mode
_sequential_counters = {}

def get_prefs(context):
    """Helper function to get the addon's preferences."""
    return context.preferences.addons[__package__].preferences

# --- Sampling Mode Implementations ---

def get_color_from_weighted(pal):
    """Chooses a color based on its weight."""
    if not pal.colors:
        return (0.8, 0.8, 0.8)

    total_weight = sum(c.weight for c in pal.colors)
    if total_weight <= 0:
        return tuple(pal.colors[random.randint(0, len(pal.colors) - 1)].color)

    rand_val = random.uniform(0, total_weight)
    current_weight = 0
    for c in pal.colors:
        current_weight += c.weight
        if rand_val <= current_weight:
            return tuple(c.color)
    
    return tuple(pal.colors[-1].color)

def get_color_from_sequential(pal):
    """Cycles through palette colors in order."""
    if not pal.colors:
        return (0.8, 0.8, 0.8)

    palette_key = pal.name
    current_index = _sequential_counters.get(palette_key, 0)
    chosen_color = tuple(pal.colors[current_index].color)
    next_index = (current_index + 1) % len(pal.colors)
    _sequential_counters[palette_key] = next_index
    return chosen_color

def get_color_from_uniform(pal):
    """Chooses a color with uniform random probability."""
    if not pal.colors:
        return (0.8, 0.8, 0.8)
    return tuple(random.choice(pal.colors).color)

# --- NEW STABLE GRADIENT IMPLEMENTATION ---

def _lerp(a, b, t):
    """Linear interpolation helper."""
    return a + t * (b - a)

def _ease(t):
    """Smoothstep interpolation helper."""
    return t * t * (3.0 - 2.0 * t)

def _interpolate_color(c1, c2, factor, mode):
    """Interpolates between two RGB colors based on the mode."""
    if mode == 'EASE':
        factor = _ease(factor)
    
    # Linear is the default for 'LINEAR', 'CARDINAL', and 'BSPLINE'
    return (
        _lerp(c1[0], c2[0], factor),
        _lerp(c1[1], c2[1], factor),
        _lerp(c1[2], c2[2], factor),
    )

def get_color_from_gradient(pal):
    """Calculates a color from a gradient using pure Python."""
    if not pal.colors:
        return (0.8, 0.8, 0.8)
    if len(pal.colors) == 1:
        return tuple(pal.colors[0].color)

    stops = sorted(pal.colors, key=lambda c: c.position)
    fac = random.random()

    # Find which two stops the random factor falls between
    if fac <= stops[0].position:
        return tuple(stops[0].color)
    if fac >= stops[-1].position:
        return tuple(stops[-1].color)

    stop_before = stops[0]
    stop_after = stops[-1]
    for i in range(len(stops) - 1):
        if stops[i].position <= fac and stops[i+1].position >= fac:
            stop_before = stops[i]
            stop_after = stops[i+1]
            break

    # Calculate how far between the two stops the factor is (0.0 to 1.0)
    dist = stop_after.position - stop_before.position
    if dist < 0.0001:
        local_fac = 0.0
    else:
        local_fac = (fac - stop_before.position) / dist
        
    return _interpolate_color(stop_before.color, stop_after.color, local_fac, pal.gradient_interpolation)

# --- Main Logic ---

def pick_color_for_frame(frame_node, prefs):
    """Determines the correct color for a frame based on the active rules."""
    def get_color_from_rule(rule):
        if rule.mode == "SINGLE":
            return tuple(rule.color)
        
        pal = storage.get_palette_by_name(prefs, rule.palette_name)
        if pal:
            if pal.sampling_mode == 'GRADIENT':
                return get_color_from_gradient(pal)
            elif pal.sampling_mode == 'WEIGHTED':
                return get_color_from_weighted(pal)
            elif pal.sampling_mode == 'SEQUENTIAL':
                return get_color_from_sequential(pal)
            else:
                return get_color_from_uniform(pal)
        return None

    label = (frame_node.label or "").lower()
    for kr in prefs.keyword_rules:
        if kr.label.lower() in label:
            return get_color_from_rule(kr)

    tree = frame_node.id_data
    if tree:
        for nr in prefs.node_rules:
            for child in tree.nodes:
                if getattr(child, "parent", None) == frame_node and child.bl_rna.identifier == nr.node_type:
                    return get_color_from_rule(nr)
    return None

def apply_color_to_frame(frame_node, col):
    """Applies a color to a frame node."""
    frame_node.use_custom_color = True
    frame_node.color = col

def on_node_tree_update(scene):
    """Handler that runs on depsgraph updates to color newly created frames."""
    prefs = get_prefs(bpy.context)
    if not prefs.auto_color:
        return

    for area in bpy.context.window.screen.areas:
        if area.type != "NODE_EDITOR": continue
        space = area.spaces.active
        if not space.node_tree or space.node_tree.bl_idname != "ShaderNodeTree": continue
        
        for node in space.node_tree.nodes:
            if node.bl_idname == "NodeFrame" and not node.get("sfc_colored"):
                if prefs.color_mode == "RANDOM":
                    color = (random.random(), random.random(), random.random())
                    apply_color_to_frame(node, color)
                    node["sfc_colored"] = True
                elif prefs.color_mode == "RULES":
                    chosen_color = pick_color_for_frame(node, prefs)
                    if chosen_color:
                        apply_color_to_frame(node, chosen_color)
                        node["sfc_colored"] = True
                    elif prefs.fallback_random:
                        color = (random.random(), random.random(), random.random())
                        apply_color_to_frame(node, color)
                        node["sfc_colored"] = True

# Handler registration management
_registered_handlers = []
def register_handlers():
    if on_node_tree_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(on_node_tree_update)
        _registered_handlers.append(on_node_tree_update)

def unregister_handlers():
    for h in _registered_handlers:
        if h in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(h)
    _registered_handlers.clear()

def register():
    pass

def unregister():
    pass