bl_info = {
    "name":        "Smart Frame Colorizer",
    "author":      "BlenPy",
    "version":     (2, 0),
    "blender":     (4, 5),
    "description": "Automatically color Frame nodes using a powerful, prioritized rule system.",
    "category":    "Node",
}

import bpy

# --- Central configuration variables ---
SUPPORTED_EDITORS = [
    ('SHADER', "Shader Editor", "Rules for the Shader Node Editor"),
    ('GEOMETRY', "Geometry Nodes", "Rules for the Geometry Nodes Editor"),
    ('COMPOSITOR', "Compositor", "Rules for the Compositor Node Editor"),
]

EDITOR_ID_MAP = {
    'SHADER': 'ShaderNodeTree',
    'GEOMETRY': 'GeometryNodeTree',
    'COMPOSITOR': 'CompositorNodeTree',
}
SUPPORTED_TREE_TYPES = set(EDITOR_ID_MAP.values())

from . import (
    preferences, operators, json_io,
    logic, ui, storage, keymap,
)

modules = (
    preferences, operators, json_io,
    logic, ui, storage, keymap,
)

def register():
    # Registers all addon modules, properties, and handlers.
    for mod in modules:
        if hasattr(mod, "register"):
            mod.register()
    
    logic.register_handlers()

def unregister():
    # Unregisters all addon modules, properties, and handlers in reverse order.
    logic.unregister_handlers()
    
    for mod in reversed(modules):
        if hasattr(mod, "unregister"):
            mod.unregister()