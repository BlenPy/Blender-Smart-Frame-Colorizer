import bpy
import random
from bpy.types import Operator
from bpy.props import IntProperty, StringProperty, FloatVectorProperty, EnumProperty
from . import json_io
from . import logic

def get_prefs(context):
    # Helper function to get the addon's preferences.
    return context.preferences.addons[__package__].preferences

def get_active_rule_list_and_index(prefs):
    # Returns the currently active rule list and index property name based on the active_rule_editor.
    
    editor = prefs.active_rule_editor
    
    if editor == 'SHADER':
        return prefs.shader_rules, "active_shader_rule_index"
    elif editor == 'GEOMETRY':
        return prefs.geometry_rules, "active_geometry_rule_index"
    elif editor == 'COMPOSITOR':
        return prefs.compositor_rules, "active_compositor_rule_index"
    
    return None, None

# --- Rule Operators ---

class SFC_OT_AddRule(Operator):
    # Add a new rule to the active editor's rule list.
    bl_idname = "sfc.add_rule"
    bl_label = "Add Rule"
    bl_description = "Add a new rule to the active list"

    def execute(self, context):
        prefs = get_prefs(context)
        rule_list, index_prop = get_active_rule_list_and_index(prefs)
        
        if rule_list is not None:
            new_rule = rule_list.add()
            new_rule.name = f"Rule #{len(rule_list)}"
            setattr(prefs, index_prop, len(rule_list) - 1)
            
        return {'FINISHED'}

class SFC_OT_RemoveRule(Operator):
    # Remove the selected rule from the active editor's list.
    bl_idname = "sfc.remove_rule"
    bl_label = "Remove Rule"
    bl_description = "Remove the selected rule from the active list"

    def execute(self, context):
        prefs = get_prefs(context)
        rule_list, index_prop = get_active_rule_list_and_index(prefs)
        
        if rule_list is not None:
            index = getattr(prefs, index_prop, 0)
            
            if 0 <= index < len(rule_list):
                rule_list.remove(index)
                setattr(prefs, index_prop, max(0, index - 1))
                
        return {'FINISHED'}

class SFC_OT_MoveRule(Operator):
    # Move the selected rule up or down in the active editor's list.
    bl_idname = "sfc.move_rule"
    bl_label = "Move Rule"
    bl_description = "Move the selected rule up or down to change its priority"

    direction: EnumProperty(
        items=[('UP', "Up", "Move rule up"), ('DOWN', "Down", "Move rule down")]
    )

    @classmethod
    def poll(cls, context):
        prefs = get_prefs(context)
        rule_list, _ = get_active_rule_list_and_index(prefs)
        return rule_list is not None and len(rule_list) > 1

    def execute(self, context):
        prefs = get_prefs(context)
        rule_list, index_prop = get_active_rule_list_and_index(prefs)
        
        if rule_list is not None:
            idx = getattr(prefs, index_prop, 0)

            if self.direction == 'UP' and idx > 0:
                rule_list.move(idx, idx - 1)
                setattr(prefs, index_prop, idx - 1)
            
            elif self.direction == 'DOWN' and idx < len(rule_list) - 1:
                rule_list.move(idx, idx + 1)
                setattr(prefs, index_prop, idx + 1)
        
        return {'FINISHED'}

# --- Palette Operators ---

class SFC_OT_MovePaletteColor(Operator):
    # Moves the active color up or down in the palette list.
    bl_idname = "sfc.move_palette_color"
    bl_label = "Move Palette Color"
    bl_description = "Move the selected color up or down in the list"

    direction: EnumProperty(items=[('UP', "Up", ""), ('DOWN', "Down", "")])

    def execute(self, context):
        prefs = get_prefs(context)
        pal = prefs.palettes[prefs.active_palette_index]
        idx = pal.active_color_index
        if self.direction == 'UP' and idx > 0:
            pal.colors.move(idx, idx - 1)
            pal.active_color_index = idx - 1
        elif self.direction == 'DOWN' and idx < len(pal.colors) - 1:
            pal.colors.move(idx, idx + 1)
            pal.active_color_index = idx + 1
        return {'FINISHED'}

class SFC_OT_AddPalette(Operator):
    bl_idname = "sfc.add_palette"
    bl_label = "Add Palette"
    bl_description = "Create a new color palette"
    
    def execute(self, context):
        prefs = get_prefs(context)
        pal = prefs.palettes.add()
        pal.name = "New Palette"
        c1 = pal.colors.add(); c1.color=(1,1,1); c1.position=0.0
        c2 = pal.colors.add(); c2.color=(0,0,0); c2.position=1.0
        prefs.active_palette_index = len(prefs.palettes) - 1
        return {'FINISHED'}

class SFC_OT_RemovePalette(Operator):
    bl_idname = "sfc.remove_palette"
    bl_label = "Remove Palette"
    bl_description = "Delete the selected color palette"
    
    def execute(self, context):
        prefs = get_prefs(context)
        i = prefs.active_palette_index
        if 0 <= i < len(prefs.palettes):
            prefs.palettes.remove(i)
            prefs.active_palette_index = max(0, i - 1)
        return {'FINISHED'}

class SFC_OT_AddPaletteColor(Operator):
    bl_idname = "sfc.add_palette_color"
    bl_label = "Add Color"
    bl_description = "Add a new color swatch to the palette"
    
    def execute(self, context):
        prefs = get_prefs(context)
        pal = prefs.palettes[prefs.active_palette_index]
        c = pal.colors.add()
        c.color=(.5,.5,.5); c.weight=1.0; c.position=0.5
        pal.active_color_index = len(pal.colors) - 1
        return {'FINISHED'}

class SFC_OT_RemovePaletteColor(Operator):
    bl_idname = "sfc.remove_palette_color"
    bl_label = "Remove Color"
    index: IntProperty()
    bl_description = "Remove the selected color swatch"
    
    def execute(self, context):
        prefs = get_prefs(context)
        pal = prefs.palettes[prefs.active_palette_index]
        if 0 <= self.index < len(pal.colors):
            pal.colors.remove(self.index)
            pal.active_color_index = max(0, min(self.index-1, len(pal.colors)-1))
        return {'FINISHED'}

class SFC_OT_SortPaletteColors(Operator):
    bl_idname = "sfc.sort_palette_colors"
    bl_label = "Sort Colors by Position"
    bl_description = "Sort color stops by position for Gradient mode"
    
    @classmethod
    def poll(cls, context):
        prefs = get_prefs(context)
        if 0 <= prefs.active_palette_index < len(prefs.palettes):
            return prefs.palettes[prefs.active_palette_index].sampling_mode == 'GRADIENT'
        return False
    
    def execute(self, context):
        prefs = get_prefs(context)
        pal = prefs.palettes[prefs.active_palette_index]
        sorted_data = sorted([(c.color, c.position, c.weight) for c in pal.colors], key=lambda x: x[1])
        pal.colors.clear()
        for color, position, weight in sorted_data:
            new_c = pal.colors.add()
            new_c.color = color
            new_c.position = position
            new_c.weight = weight
        return {'FINISHED'}

# --- UI Panel Operators ---

class SFC_OT_ApplyQuickColor(Operator):
    bl_idname = "sfc.apply_quick_color"
    bl_label = "Quick Color"
    bl_description = "Apply a chosen color to selected frames (Shortcut: Shift+Alt+Q)"
    color: FloatVectorProperty(name="Color", subtype='COLOR', default=(0.8, 0.8, 0.8))
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
        
    def execute(self, context):
        for node in context.selected_nodes:
            if node.bl_idname == 'NodeFrame':
                node.use_custom_color = True
                node.color = self.color
        return {'FINISHED'}

class SFC_OT_ApplyColorAllFrames(Operator):
    # Forceful operator that re-applies rules to ALL frames, ignoring whether they already have a color.
    
    bl_idname = "sfc.apply_color_all_frames"
    bl_label = "Update All Frames"
    bl_description = "Re-applies coloring rules to all frames in the current tree (Shortcut: Shift+Alt+A)"
    
    def execute(self, context):
        prefs = get_prefs(context)
        space = context.space_data
        if not space or not space.node_tree:
            return {'CANCELLED'}
            
        tree_type = space.node_tree.bl_idname
        editor_context = None
        if tree_type == 'ShaderNodeTree': editor_context = 'SHADER'
        elif tree_type == 'GeometryNodeTree': editor_context = 'GEOMETRY'
        elif tree_type == 'CompositorNodeTree': editor_context = 'COMPOSITOR'
        
        if not editor_context:
            return {'CANCELLED'}
        
        for node in space.node_tree.nodes:
            if node.bl_idname == "NodeFrame":
                target_color = logic.pick_color_for_frame(node, prefs, editor_context)
                if target_color:
                    logic.apply_color_to_frame(node, target_color)
                elif prefs.fallback_random:
                    # Apply a new random color, seeded by frame name
                    rng = random.Random(node.name)
                    logic.apply_color_to_frame(node, (rng.random(), rng.random(), rng.random()))
                    
        return {'FINISHED'}

class SFC_OT_ApplyColorSelectedFrames(Operator):
    # Forceful operator that re-applies rules to SELECTED frames, ignoring whether they already have a color.
    
    bl_idname = "sfc.apply_color_selected_frames"
    bl_label = "Update Selected"
    bl_description = "Re-applies coloring rules to selected frames (Shortcut: Shift+Alt+U)"
    
    def execute(self, context):
        prefs = get_prefs(context)
        space = context.space_data
        if not space or not space.node_tree:
            return {'CANCELLED'}
            
        tree_type = space.node_tree.bl_idname
        editor_context = None
        if tree_type == 'ShaderNodeTree': editor_context = 'SHADER'
        elif tree_type == 'GeometryNodeTree': editor_context = 'GEOMETRY'
        elif tree_type == 'CompositorNodeTree': editor_context = 'COMPOSITOR'
        
        if not editor_context:
            return {'CANCELLED'}
        
        for node in context.selected_nodes:
            if node.bl_idname == "NodeFrame":
                target_color = logic.pick_color_for_frame(node, prefs, editor_context)
                if target_color:
                    logic.apply_color_to_frame(node, target_color)
                elif prefs.fallback_random:
                    rng = random.Random(node.name)
                    logic.apply_color_to_frame(node, (rng.random(), rng.random(), rng.random()))

        return {'FINISHED'}

class SFC_OT_ResetColorSelectedFrames(Operator):
    bl_idname = "sfc.reset_color_selected_frames"
    bl_label = "Reset Selected"
    bl_description = "Remove custom color from selected frames (Shortcut: Shift+Alt+R)"
    
    def execute(self, context):
        for node in context.selected_nodes:
            if node.bl_idname == 'NodeFrame':
                node.use_custom_color = False
        return {'FINISHED'}

class SFC_OT_ResetColorAllFrames(Operator):
    bl_idname = "sfc.reset_color_all_frames"
    bl_label = "Reset All"
    bl_description = "Remove custom color from all frames in the current tree (Shortcut: Shift+Alt+X)"
    
    def execute(self, context):
        tree = context.space_data.node_tree
        if tree:
            for node in tree.nodes:
                if node.bl_idname == 'NodeFrame':
                    node.use_custom_color = False
        return {'FINISHED'}

# --- Config Operators ---

class SFC_OT_LoadConfig(Operator):
    bl_idname = "sfc.load_config"
    bl_label = "Load Config"
    bl_description = "Load rules and palettes from the specified JSON file"
    
    def execute(self, context):
        prefs = get_prefs(context)
        path = bpy.path.abspath(prefs.json_path)
        try:
            json_io.import_config(path, prefs)
            self.report({'INFO'}, "Config loaded successfully")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to load JSON: {e}")
            return {'CANCELLED'}
        return {'FINISHED'}

class SFC_OT_SaveConfig(Operator):
    bl_idname = "sfc.save_config"
    bl_label = "Save Config"
    bl_description = "Save rules and palettes to a JSON file"
    filepath: StringProperty(subtype='FILE_PATH')
    
    def invoke(self, context, event):
        prefs = get_prefs(context)
        if prefs.json_path:
            self.filepath = bpy.path.abspath(prefs.json_path)
        elif bpy.data.is_saved:
            blend_name = bpy.path.display_name_from_filepath(bpy.data.filepath)
            self.filepath = bpy.path.abspath(f"//{blend_name}_sfc_config.json")
        else:
            self.filepath = "sfc_config.json"
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
        
    def execute(self, context):
        prefs = get_prefs(context)
        try:
            json_io.export_config(self.filepath, prefs)
            prefs.json_path = bpy.path.relpath(self.filepath)
            self.report({'INFO'}, f"Saved to {self.filepath}")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to save JSON: {e}")
            return {'CANCELLED'}
        return {'FINISHED'}

classes = (
    SFC_OT_AddRule,
    SFC_OT_RemoveRule,
    SFC_OT_MoveRule,
    SFC_OT_MovePaletteColor,
    SFC_OT_ApplyQuickColor,
    SFC_OT_ApplyColorAllFrames,
    SFC_OT_ApplyColorSelectedFrames,
    SFC_OT_ResetColorSelectedFrames,
    SFC_OT_ResetColorAllFrames,
    SFC_OT_AddPalette,
    SFC_OT_RemovePalette,
    SFC_OT_AddPaletteColor,
    SFC_OT_RemovePaletteColor,
    SFC_OT_SortPaletteColors,
    SFC_OT_LoadConfig,
    SFC_OT_SaveConfig,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass