import bpy
import random
from . import storage

_sequential_counters = {}

def get_prefs(context):
    # Helper function to get the addon's preferences.
    return context.preferences.addons[__package__].preferences

# --- Sampling Mode Implementations ---

def get_color_from_weighted(pal, rng):
    # Chooses a color based on its weight, using a stable RNG.
    if not pal.colors: return (0.8, 0.8, 0.8)
    total_weight = sum(c.weight for c in pal.colors)
    if total_weight <= 0: return tuple(rng.choice(pal.colors).color)
    rand_val = rng.uniform(0, total_weight)
    current_weight = 0
    for c in pal.colors:
        current_weight += c.weight
        if rand_val <= current_weight: return tuple(c.color)
    return tuple(pal.colors[-1].color)

def get_color_from_sequential(pal):
    # Cycles through palette colors in order. (Not random, no change).
    if not pal.colors: return (0.8, 0.8, 0.8)
    palette_key = pal.name
    current_index = _sequential_counters.get(palette_key, 0)
    chosen_color = tuple(pal.colors[current_index].color)
    _sequential_counters[palette_key] = (current_index + 1) % len(pal.colors)
    return chosen_color

def get_color_from_uniform(pal, rng):
    # Chooses a color with uniform random probability, using a stable RNG.
    if not pal.colors: return (0.8, 0.8, 0.8)
    return tuple(rng.choice(pal.colors).color)

def _lerp(a, b, t): return a + t * (b - a)
def _ease(t): return t * t * (3.0 - 2.0 * t)

def _interpolate_color(c1, c2, factor, mode):
    # Interpolates between two RGB colors based on the mode.
    if mode == 'EASE': factor = _ease(factor)
    return (_lerp(c1[0], c2[0], factor), _lerp(c1[1], c2[1], factor), _lerp(c1[2], c2[2], factor))

def get_color_from_gradient(pal, rng):
    # Calculates a color from a gradient, using a stable RNG.
    if not pal.colors: return (0.8, 0.8, 0.8)
    if len(pal.colors) == 1: return tuple(pal.colors[0].color)
    stops = sorted(pal.colors, key=lambda c: c.position)
    fac = rng.random() # Use the stable RNG
    if fac <= stops[0].position: return tuple(stops[0].color)
    if fac >= stops[-1].position: return tuple(stops[-1].color)
    stop_before, stop_after = stops[0], stops[-1]
    for i in range(len(stops) - 1):
        if stops[i].position <= fac and stops[i+1].position >= fac:
            stop_before, stop_after = stops[i], stops[i+1]
            break
    dist = stop_after.position - stop_before.position
    local_fac = (fac - stop_before.position) / dist if dist > 0.0001 else 0.0
    return _interpolate_color(stop_before.color, stop_after.color, local_fac, pal.gradient_interpolation)

# --- Main Logic ---

def pick_color_for_frame(frame_node, prefs, editor_context):
    # Determines the correct color for a frame based on the active editor context and the user's rules.
    
    rng = random.Random(frame_node.name)
    
    rule_list = None
    if editor_context == 'SHADER':
        rule_list = prefs.shader_rules
    elif editor_context == 'GEOMETRY':
        rule_list = prefs.geometry_rules
    elif editor_context == 'COMPOSITOR':
        rule_list = prefs.compositor_rules
    
    if not rule_list:
        return None 

    def get_color_from_rule_match(rule):
        if rule.mode == "SINGLE":
            return tuple(rule.color)
        
        pal = storage.get_palette_by_name(prefs, rule.palette_name)
        if pal:
            mode_map = {
                'GRADIENT': get_color_from_gradient,
                'WEIGHTED': get_color_from_weighted,
                'UNIFORM': get_color_from_uniform,
            }
            # Special case: Sequential doesn't use RNG
            if pal.sampling_mode == 'SEQUENTIAL':
                return get_color_from_sequential(pal)
            
            # Pass the stable RNG to the other sampling functions
            sample_func = mode_map.get(pal.sampling_mode, get_color_from_uniform)
            return sample_func(pal, rng)
        
        return (0.8, 0.8, 0.8) 

    for rule in rule_list:
        if rule.rule_type == 'KEYWORD':
            label = (frame_node.label or "").lower()
            if rule.keyword and rule.keyword.lower() in label:
                return get_color_from_rule_match(rule) 
        
        elif rule.rule_type == 'NODE_TYPE':
            tree = frame_node.id_data
            if tree:
                for child in tree.nodes:
                    if getattr(child, "parent", None) == frame_node and child.bl_rna.identifier == rule.node_type:
                        return get_color_from_rule_match(rule) 

    return None # No rules matched

def apply_color_to_frame(frame_node, col):
    # Applies a color to a frame node only if it's different from the current color.
    if not frame_node.use_custom_color or any(abs(c1 - c2) > 0.001 for c1, c2 in zip(frame_node.color, col)):
        frame_node.use_custom_color = True
        frame_node.color = col

def on_node_tree_update(scene):
    # Smarter handler that checks and corrects frame colors on every update.
    prefs = get_prefs(bpy.context)
    if not prefs.auto_color: return

    for area in bpy.context.window.screen.areas:
        if area.type != "NODE_EDITOR": continue
        space = area.spaces.active
        if not space.node_tree: continue
        
        tree_type = space.node_tree.bl_idname
        editor_context = None
        if tree_type == 'ShaderNodeTree':
            editor_context = 'SHADER'
        elif tree_type == 'GeometryNodeTree':
            editor_context = 'GEOMETRY'
        elif tree_type == 'CompositorNodeTree':
            editor_context = 'COMPOSITOR'
        
        if not editor_context:
            continue
            
        for node in space.node_tree.nodes:
            if node.bl_idname == "NodeFrame":
                if prefs.color_mode == "RULES":
                    target_color = pick_color_for_frame(node, prefs, editor_context)
                    if target_color:
                        apply_color_to_frame(node, target_color)
                    # If no rule matched, check fallback
                    elif prefs.fallback_random and not node.use_custom_color:
                        # Only apply fallback if the node has no color
                        apply_color_to_frame(node, (random.random(), random.random(), random.random()))
                
                elif prefs.color_mode == "RANDOM" and not node.use_custom_color:
                    # Only apply random if the node has no color
                    apply_color_to_frame(node, (random.random(), random.random(), random.random()))

_registered_handlers = []
def register_handlers():
    # Registers the depsgraph update handler.
    if on_node_tree_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(on_node_tree_update)
        _registered_handlers.append(on_node_tree_update)

def unregister_handlers():
    # Unregisters the depsgraph update handler.
    for h in _registered_handlers:
        if h in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(h)
    _registered_handlers.clear()

def register(): pass
def unregister(): pass