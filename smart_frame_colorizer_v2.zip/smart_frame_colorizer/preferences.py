import bpy
from bpy.props import (
    BoolProperty, EnumProperty, StringProperty,
    CollectionProperty, IntProperty,
    FloatVectorProperty, FloatProperty
)
from bpy.types import AddonPreferences, PropertyGroup, UIList

# --- Helper Functions ---

def get_nodes_by_base_class(base_class):
    # Helper function to find all node subclasses.
    items = []
    for name in dir(bpy.types):
        cls = getattr(bpy.types, name)
        if isinstance(cls, type) and issubclass(cls, base_class) and cls is not base_class:
            try: 
                items.append((cls.bl_rna.identifier, cls.bl_rna.name, ""))
            except AttributeError: 
                continue
    return sorted(items, key=lambda x: x[1])

def get_shader_nodes(self, context):
    return get_nodes_by_base_class(bpy.types.ShaderNode)

def get_geometry_nodes(self, context):
    return get_nodes_by_base_class(bpy.types.GeometryNode)

def get_compositor_nodes(self, context):
    return get_nodes_by_base_class(bpy.types.CompositorNode)

# --- Palette PropertyGroups ---

class SFC_PaletteColorItem(PropertyGroup):
    color: FloatVectorProperty(name="Color", subtype='COLOR', size=3, min=0.0, max=1.0, default=(1.0, 1.0, 1.0), description="The color swatch")
    position: FloatProperty(name="Position", description="Position on the gradient (0-1)", default=0.0, min=0.0, max=1.0, subtype='FACTOR')
    weight: FloatProperty(name="Weight", description="Probability weight for this color in 'Weighted Random' mode (0-100%)", default=1.0, min=0.0, max=100.0)

class SFC_PaletteItem(PropertyGroup):
    name: StringProperty(name="Palette Name", default="New Palette", description="A unique name for this palette")
    sampling_mode: EnumProperty(name="Sampling Mode", items=[("UNIFORM", "Uniform Random", "Each color has an equal chance"), ("WEIGHTED", "Weighted Random", "Chance is based on color weight"), ("GRADIENT", "Gradient", "Interpolates colors like a Color Ramp"), ("SEQUENTIAL", "Sequential", "Cycles through colors in order")], default="UNIFORM", description="How colors are chosen from this palette")
    gradient_interpolation: EnumProperty(name="Interpolation", items=[('LINEAR', "Linear", "Linear interpolation"), ('EASE', "Ease", "Ease interpolation")], default="LINEAR", description="The interpolation method for 'Gradient' mode")
    colors: CollectionProperty(type=SFC_PaletteColorItem)
    active_color_index: IntProperty(default=0)

# --- Separate RuleItem and UIList for Each Editor ---

class SFC_BaseRuleItem(PropertyGroup):
    # Base class for properties shared by all rule types.
    name: StringProperty(name="Name", default="New Rule")
    rule_type: EnumProperty(name="Rule Type", items=[('NODE_TYPE', "Node Type", ""), ('KEYWORD', "Keyword", "")], default='NODE_TYPE', description="The type of condition to check for this rule")
    keyword: StringProperty(name="Keyword", default="Keyword", description="The text to search for in a frame's label")
    mode: EnumProperty(name="Mode", items=[("SINGLE", "Single Color", ""), ("PALETTE", "Use Palette", "")], default="SINGLE", description="What to do when this rule is matched")
    color: FloatVectorProperty(name="Color", subtype='COLOR', size=3, min=0.0, max=1.0, default=(0.5, 0.5, 0.5), description="The color to apply")
    
    palette_name: StringProperty(
        name="Palette Name", 
        description="The palette to use", 
        default=""
    )

class SFC_ShaderRuleItem(SFC_BaseRuleItem):
    # A rule specific to the Shader Editor.
    node_type: EnumProperty(name="Node Type", items=get_shader_nodes, description="The node type to search for inside a frame")

class SFC_GeometryRuleItem(SFC_BaseRuleItem):
    # A rule specific to the Geometry Node Editor.
    node_type: EnumProperty(name="Node Type", items=get_geometry_nodes, description="The node type to search for inside a frame")

class SFC_CompositorRuleItem(SFC_BaseRuleItem):
    # A rule specific to the Compositor.
    node_type: EnumProperty(name="Node Type", items=get_compositor_nodes, description="The node type to search for inside a frame")

def draw_rule_list_item(layout, item):
    # Helper function to draw a rule item in a UI list.
    if item.rule_type == 'NODE_TYPE':
        node_name = item.node_type # Default fallback
        
        # Get the class from bpy.types using its string name
        node_class = getattr(bpy.types, item.node_type, None)
        
        # If the class exists, get its proper name
        if node_class:
            node_name = node_class.bl_rna.name
            
        icon = 'NODE'
        layout.label(text=node_name, icon=icon)
    else:
        label = item.keyword
        icon = 'FONT_DATA'
        layout.label(text=label, icon=icon)

class SFC_UL_PaletteColors(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        pal, sw = data, item; row = layout.row(); row.prop(sw, "color", text="")
        if pal.sampling_mode == "WEIGHTED": row.prop(sw, "weight", text="")
        elif pal.sampling_mode == "GRADIENT": row.prop(sw, "position", slider=True, text="")

class SFC_UL_ShaderRules(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        draw_rule_list_item(layout, item)

class SFC_UL_GeometryRules(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        draw_rule_list_item(layout, item)

class SFC_UL_CompositorRules(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        draw_rule_list_item(layout, item)

class SFC_UL_Palettes(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index): layout.label(text=item.name, icon='GROUP_VCOL')

# --- Main Preferences Class ---

class SFC_Preferences(AddonPreferences):
    bl_idname = __name__.split(".")[0]

    # Main addon settings
    active_tab: EnumProperty(items=[('SETTINGS', "Settings", ""), ('RULES', "Rules", ""), ('PALETTES', "Palettes", "")], default='SETTINGS')
    auto_color: BoolProperty(name="Auto Color", default=True)
    color_mode: EnumProperty(name="Color Mode", items=[("RANDOM", "Random", ""), ("RULES", "By Rules", "")], default="RULES")
    fallback_random: BoolProperty(name="Fallback to Random", default=True)
    json_path: StringProperty(name="Config File Path", subtype='FILE_PATH')
    
    # Palette settings
    palettes: CollectionProperty(type=SFC_PaletteItem)
    active_palette_index: IntProperty(default=0)
    
    # --- Rule Settings (Three separate lists) ---
    active_rule_editor: EnumProperty(
        name="Active Rule Editor",
        items=[
            ('SHADER', "Shader", "Shader Node Editor Rules"),
            ('GEOMETRY', "Geometry", "Geometry Node Editor Rules"),
            ('COMPOSITOR', "Compositor", "Compositor Rules"),
        ],
        default='SHADER'
    )
    
    shader_rules: CollectionProperty(type=SFC_ShaderRuleItem)
    active_shader_rule_index: IntProperty(default=0)
    
    geometry_rules: CollectionProperty(type=SFC_GeometryRuleItem)
    active_geometry_rule_index: IntProperty(default=0)
    
    compositor_rules: CollectionProperty(type=SFC_CompositorRuleItem)
    active_compositor_rule_index: IntProperty(default=0)

    # Draw_rule_editor_box to use prop_search and tighter spacing
    def draw_rule_editor_box(self, layout, rule):
        """Helper function to draw the 'Edit Rule' box."""
        box = layout.box()
        col = box.column()
        col.scale_y = 1.1
        
        col.label(text="Rule Type")
        col.prop(rule, "rule_type", text="")
        col.separator(factor=0.5)

        if rule.rule_type == 'NODE_TYPE':
            col.prop(rule, "node_type", text="")
        else:
            col.prop(rule, "keyword", text="")
        
        col.separator(factor=0.5) 
        col.prop(rule, "mode", text="")
        
        col.separator(factor=0.5) 
        if rule.mode == 'SINGLE':
            col.prop(rule, "color", text="")
        else:
            col.prop_search(rule, "palette_name", self, "palettes", text="Palette")

    # --- Draw_rules_tab ---
    def draw_rules_tab(self, context, layout):
        # Put the editor-switching buttons in a row
        row = layout.row()
        row.prop(self, "active_rule_editor", expand=True)
        layout.separator(factor=0.5)
        
        col = layout.column()
        col.scale_y = 1.1
        
        # Determine which list and index to show
        rule_list = None
        index = None
        list_name = ""
        ui_list_name = ""
        
        if self.active_rule_editor == 'SHADER':
            rule_list = self.shader_rules
            list_name = "shader_rules"
            index = "active_shader_rule_index"
            ui_list_name = "SFC_UL_ShaderRules"
        
        elif self.active_rule_editor == 'GEOMETRY':
            rule_list = self.geometry_rules
            list_name = "geometry_rules"
            index = "active_geometry_rule_index"
            ui_list_name = "SFC_UL_GeometryRules"
            
        elif self.active_rule_editor == 'COMPOSITOR':
            rule_list = self.compositor_rules
            list_name = "compositor_rules"
            index = "active_compositor_rule_index"
            ui_list_name = "SFC_UL_CompositorRules"

        if rule_list is None:
            return

        col.label(text=f"{self.active_rule_editor.capitalize()} Rules")
        row = col.row()
        
        # Draw the template list for the active editor
        row.template_list(ui_list_name, "", self, list_name, self, index)
        
        # Add/Remove/Move buttons
        col_buttons = row.column(align=True)
        col_buttons.operator("sfc.add_rule", icon="ADD", text="")
        col_buttons.operator("sfc.remove_rule", icon="REMOVE", text="")
        col_buttons.separator(factor=0.5)
        op_up = col_buttons.operator("sfc.move_rule", icon='TRIA_UP', text="")
        op_up.direction = 'UP'
        op_down = col_buttons.operator("sfc.move_rule", icon='TRIA_DOWN', text="")
        op_down.direction = 'DOWN'
        
        col.separator(factor=0.5)
        
        # Get the active index number
        active_index_val = getattr(self, index, 0)
        
        # Draw the rule editor box
        if 0 <= active_index_val < len(rule_list):
            active_rule = rule_list[active_index_val]
            self.draw_rule_editor_box(col, active_rule)

    def draw_palettes_tab(self, context, layout):
        col_main = layout.column()
        col_main.scale_y = 0.9
        
        col_main.label(text="Palettes")
        row_list = col_main.row()
        row_list.template_list("SFC_UL_Palettes", "", self, "palettes", self, "active_palette_index")
        col_buttons_list = row_list.column(align=True)
        col_buttons_list.operator("sfc.add_palette", icon="ADD", text="")
        col_buttons_list.operator("sfc.remove_palette", icon="REMOVE", text="")

        if not self.palettes or not (0 <= self.active_palette_index < len(self.palettes)): 
            return
            
        col_main.separator(factor=0.5)

        pal = self.palettes[self.active_palette_index]
        split_editor = col_main.split(factor=0.5)
        
        left_col = split_editor.column()
        left_col.label(text="Edit Palette")
        left_col.prop(pal, "name", text="")
        left_col.separator(factor=0.5) 
        left_col.prop(pal, "sampling_mode", text="")
        left_col.separator(factor=0.5) 
        if pal.sampling_mode == "GRADIENT": left_col.prop(pal, "gradient_interpolation", text="")
        elif pal.sampling_mode == "WEIGHTED":
            left_col.separator(factor=0.5) 
            total = sum(c.weight for c in pal.colors)
            icon = 'CHECKMARK' if abs(total - 100.0) < 0.01 else 'ERROR'
            left_col.label(text=f"Total Weight: {total:.1f}/100", icon=icon)

        right_col = split_editor.column()
        right_col.label(text="Colors")
        row_colors = right_col.row()
        row_colors.template_list("SFC_UL_PaletteColors", "", pal, "colors", pal, "active_color_index")
        col_color_buttons = row_colors.column(align=True)
        col_color_buttons.operator("sfc.add_palette_color", icon="ADD", text="")
        op_rem = col_color_buttons.operator("sfc.remove_palette_color", icon="REMOVE", text=""); op_rem.index = pal.active_color_index
        col_color_buttons.separator(factor=0.5)
        row_up = col_color_buttons.row(align=True); row_up.enabled = pal.active_color_index > 0
        op_up = row_up.operator("sfc.move_palette_color", icon='TRIA_UP', text=""); op_up.direction = 'UP'
        row_down = col_color_buttons.row(align=True); row_down.enabled = pal.active_color_index < len(pal.colors) - 1
        op_down = row_down.operator("sfc.move_palette_color", icon='TRIA_DOWN', text=""); op_down.direction = 'DOWN'

    def draw_settings_tab(self, context, layout):
        col = layout.column()
        col.scale_y = 1.1
        
        col.label(text="General Behavior", icon="PRESET")
        col.prop(self, "auto_color")
        if self.color_mode == "RULES": col.prop(self, "fallback_random")
        col.separator(factor=0.5)
        col.label(text="Config Import/Export", icon="FILE_FOLDER")
        col_config = col.column(); col_config.enabled = self.color_mode == 'RULES' 
        col_config.prop(self, "json_path", text="")
        row = col_config.row(align=True)
        row.operator("sfc.load_config", text="Load", icon="FILE_REFRESH")
        row.operator("sfc.save_config", text="Save", icon="FILE_TICK")

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "color_mode")
        layout.separator(factor=0.5)
        row = layout.row(); row.prop(self, "active_tab", expand=True)
        main_col = layout.column()
        is_rules_mode = self.color_mode == 'RULES'
        if self.active_tab == 'RULES':
            if not is_rules_mode: main_col.label(text="Rules are only available in 'By Rules' mode.", icon='INFO')
            else: self.draw_rules_tab(context, main_col)
        elif self.active_tab == 'PALETTES':
            if not is_rules_mode: main_col.label(text="Palettes are only available in 'By Rules' mode.", icon='INFO')
            else: self.draw_palettes_tab(context, main_col)
        elif self.active_tab == 'SETTINGS':
            self.draw_settings_tab(context, main_col)

# PropertyGroups must be registered BEFORE the classes that use them.
classes = (
    # 1. Palettes
    SFC_PaletteColorItem, 
    SFC_PaletteItem, 
    
    # 2. Rule base and items
    SFC_BaseRuleItem,
    SFC_ShaderRuleItem,
    SFC_GeometryRuleItem,
    SFC_CompositorRuleItem,
    
    # 3. UI Lists
    SFC_UL_PaletteColors, 
    SFC_UL_ShaderRules,
    SFC_UL_GeometryRules,
    SFC_UL_CompositorRules,
    SFC_UL_Palettes,
    
    # 4. Preferences class (which uses all the above)
    SFC_Preferences,
)

def register():
    for cls in classes: bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        try: bpy.utils.unregister_class(cls)
        except RuntimeError: pass