import json
import bpy

def export_config(filepath, prefs):
    # Exports the addon's rules and palettes to a JSON file.
    
    data = {"palettes": [], "editor_rule_sets": []}
    
    # 1. Export palettes
    for p in prefs.palettes:
        pd = {
            "name": p.name, 
            "sampling_mode": p.sampling_mode, 
            "gradient_interpolation": p.gradient_interpolation, 
            "colors": []
        }
        for c in p.colors:
            pd["colors"].append({
                "color": list(c.color), 
                "weight": c.weight, 
                "position": c.position
            })
        data["palettes"].append(pd)
        
    # 2. Export the three separate rule lists
    rule_sets = [
        ("SHADER", prefs.shader_rules),
        ("GEOMETRY", prefs.geometry_rules),
        ("COMPOSITOR", prefs.compositor_rules)
    ]

    for set_name, rule_list in rule_sets:
        rule_set_data = {"name": set_name, "rules": []}
        for r in rule_list:
            rule_set_data["rules"].append({
                "rule_type": r.rule_type,
                "keyword": r.keyword,
                "node_type": r.node_type,
                "mode": r.mode,
                "color": list(r.color),
                "palette_name": r.palette_name
            })
        data["editor_rule_sets"].append(rule_set_data)
        
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

def import_config(filepath, prefs):
    # Imports rules and palettes from a JSON file, overwriting current settings.
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        raise Exception(f"File not found: {filepath}")
    except json.JSONDecodeError:
        raise Exception("File is not a valid JSON.")

    # 1. Clear all existing data
    prefs.palettes.clear()
    prefs.shader_rules.clear()
    prefs.geometry_rules.clear()
    prefs.compositor_rules.clear()

    # 2. Import palettes
    for pd in data.get("palettes", []):
        p = prefs.palettes.add()
        p.name = pd.get("name", "Unnamed Palette")
        p.sampling_mode = pd.get("sampling_mode", "UNIFORM")
        p.gradient_interpolation = pd.get("gradient_interpolation", "LINEAR")
        for cd in pd.get("colors", []):
            c = p.colors.add()
            c.color = tuple(cd.get("color", [1, 1, 1]))
            c.weight = cd.get("weight", 1.0)
            c.position = cd.get("position", 0.0)
    
    # 3. Import the editor rule sets
    for rule_set in data.get("editor_rule_sets", []):
        set_name = rule_set.get("name")
        target_list = None
        
        if set_name == "SHADER":
            target_list = prefs.shader_rules
        elif set_name == "GEOMETRY":
            target_list = prefs.geometry_rules
        elif set_name == "COMPOSITOR":
            target_list = prefs.compositor_rules
        
        if target_list is None:
            continue
            
        for rd in rule_set.get("rules", []):
            r = target_list.add()
            r.mode = rd.get("mode", "SINGLE")
            r.color = tuple(rd.get("color", [0.5, 0.5, 0.5]))
            r.palette_name = rd.get("palette_name", "")
            
            # Conditional assignment based on rule type
            rule_type_from_json = rd.get("rule_type", "NODE_TYPE")
            r.rule_type = rule_type_from_json
            
            if rule_type_from_json == "NODE_TYPE":
                r.node_type = rd.get("node_type", "")
            else: # It's "KEYWORD"
                r.keyword = rd.get("keyword", "")

    # 4. Handle importing OLD config files (with the single "rules" key)
    if "rules" in data:
        for rd in data.get("rules", []):
            # Old rules are all loaded into the SHADER list by default
            r = prefs.shader_rules.add()
            r.mode = rd.get("mode", "SINGLE")
            r.color = tuple(rd.get("color", [0.5, 0.5, 0.5]))
            r.palette_name = rd.get("palette_name", "")
            
            # Conditional assignment based on rule type
            rule_type_from_json = rd.get("rule_type", "NODE_TYPE")
            r.rule_type = rule_type_from_json
            
            if rule_type_from_json == "NODE_TYPE":
                r.node_type = rd.get("node_type", "ShaderNodeBsdfPrincipled")
            else: # It's "KEYWORD"
                r.keyword = rd.get("keyword", "")