# ui.py

import bpy
from bpy.types import Panel, Operator

class SFC_PT_ManualColorPanel(Panel):
    """The main UI panel in the Shader Editor's sidebar (N-Panel)."""
    bl_label = "Smart Frame Colorizer"
    bl_idname = "SFC_PT_manual_color"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Tool'

    @classmethod
    def poll(cls, context):
        s = context.space_data
        return s and s.type == 'NODE_EDITOR' and s.node_tree

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__package__].preferences

        box = layout.box()
        row = box.row()
        row.label(text=f"Auto Color: {'ON' if prefs.auto_color else 'OFF'}", icon='CHECKMARK' if prefs.auto_color else 'ERROR')
        row.operator("sfc.open_preferences", text="", icon='PREFERENCES')

        box = layout.box()
        box.operator("sfc.apply_quick_color", text="Quick Color Popup", icon='COLOR')
        
        box = layout.box()
        box.label(text="Apply Rules", icon='PLAY')
        col = box.column()
        col.enabled = prefs.color_mode == 'RULES'
        col.operator("sfc.apply_color_selected_frames", text="Update Selected")
        col.operator("sfc.apply_color_all_frames", text="Update All Frames")
        if prefs.color_mode == 'RULES':
            box.prop(prefs, "fallback_random")
        
        box = layout.box()
        box.label(text="Reset Colors", icon='TRASH')
        col = box.column()
        col.operator("sfc.reset_color_selected_frames", text="Reset Selected")
        col.operator("sfc.reset_color_all_frames", text="Reset All")

class SFC_OT_OpenPreferences(Operator):
    """An operator to quickly open the addon preferences."""
    bl_idname = "sfc.open_preferences"
    bl_label = "Open Addon Preferences"
    bl_description = "Open the preferences window for this addon"

    def execute(self, context):
        bpy.ops.screen.userpref_show('INVOKE_DEFAULT')
        context.preferences.active_section = 'ADDONS'
        context.window_manager.addon_search = "Smart Frame Colorizer"
        return {'FINISHED'}

classes = (
    SFC_PT_ManualColorPanel,
    SFC_OT_OpenPreferences,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass