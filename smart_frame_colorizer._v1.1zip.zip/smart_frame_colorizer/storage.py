# storage.py

def get_palette_by_name(prefs, name):
    """Finds and returns a palette by its name."""
    for p in prefs.palettes:
        if p.name == name:
            return p
    return None

def get_node_rule_by_type(prefs, node_type):
    """Finds and returns a node rule by its node_type."""
    for nr in prefs.node_rules:
        if nr.node_type == node_type:
            return nr
    return None

def get_keyword_rule_by_label(prefs, label):
    """Finds and returns a keyword rule by its label (case-insensitive)."""
    label_lower = label.lower()
    for kr in prefs.keyword_rules:
        if kr.label.lower() == label_lower:
            return kr
    return None