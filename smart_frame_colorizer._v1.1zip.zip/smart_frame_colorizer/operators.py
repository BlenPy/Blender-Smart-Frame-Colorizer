# operators.py

import bpy
import random
from bpy.types import Operator
from bpy.props import IntProperty, StringProperty, FloatVectorProperty, EnumProperty
from . import json_io
from . import logic

def get_prefs(context):
    """Helper function to get the addon's preferences."""
    return context.preferences.addons[__package__].preferences

class SFC_OT_MovePaletteColor(Operator):
    """Moves the active color up or down in the palette list."""
    bl_idname = "sfc.move_palette_color"
    bl_label = "Move Palette Color"
    bl_description = "Move the selected color up or down in the list"

    direction: EnumProperty(
        items=[('UP', "Up", "Move color up"), ('DOWN', "Down", "Move color down")]
    )

    @classmethod
    def poll(cls, context):
        prefs = get_prefs(context)
        if not (0 <= prefs.active_palette_index < len(prefs.palettes)):
            return False
        pal = prefs.palettes[prefs.active_palette_index]
        return len(pal.colors) > 1

    def execute(self, context):
        prefs = get_prefs(context)
        pal = prefs.palettes[prefs.active_palette_index]
        idx = pal.active_color_index

        if self.direction == 'UP' and idx > 0:
            pal.colors.move(idx, idx - 1)
            pal.active_color_index = idx - 1
        
        elif self.direction == 'DOWN' and idx < len(pal.colors) - 1:
            pal.colors.move(idx, idx + 1)
            pal.active_color_index = idx + 1
        
        return {'FINISHED'}

class SFC_OT_ApplyQuickColor(Operator):
    """Opens a color picker popup to apply a color to selected frames."""
    bl_idname = "sfc.apply_quick_color"
    bl_label = "Quick Color Popup"
    bl_description = "Apply a chosen color to selected frames via a popup (Shortcut: Shift+Alt+Q)"

    color: FloatVectorProperty(
        name="Color", subtype='COLOR', size=3,
        min=0.0, max=1.0, default=(0.8, 0.8, 0.8)
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        for node in context.selected_nodes:
            if node.bl_idname == 'NodeFrame':
                node.use_custom_color = True
                node.color = self.color
        return {'FINISHED'}

class SFC_OT_ApplyColorAllFrames(Operator):
    """Applies coloring rules to all Frame nodes in the active node tree."""
    bl_idname = "sfc.apply_color_all_frames"
    bl_label = "Update All Frames"
    bl_description = "Re-applies coloring rules to all Frame nodes (Shortcut: Shift+Alt+A)"
    
    @classmethod
    def poll(cls, context):
        space = context.space_data
        return space and space.type == 'NODE_EDITOR' and space.node_tree

    def execute(self, context):
        tree = context.space_data.node_tree
        for node in tree.nodes:
            if node.bl_idname == 'NodeFrame':
                if 'sfc_colored' in node:
                    del node['sfc_colored']
        logic.on_node_tree_update(context.scene)
        return {'FINISHED'}

class SFC_OT_ApplyColorSelectedFrames(Operator):
    """Applies coloring rules to all selected Frame nodes."""
    bl_idname = "sfc.apply_color_selected_frames"
    bl_label = "Update Selected Frames"
    bl_description = "Re-applies coloring rules to selected Frame nodes (Shortcut: Shift+Alt+U)"

    @classmethod
    def poll(cls, context):
        return context.selected_nodes

    def execute(self, context):
        for node in context.selected_nodes:
            if node.bl_idname == 'NodeFrame':
                if 'sfc_colored' in node:
                    del node['sfc_colored']
        logic.on_node_tree_update(context.scene)
        return {'FINISHED'}

class SFC_OT_ResetColorSelectedFrames(Operator):
    """Removes custom color from selected Frame nodes."""
    bl_idname = "sfc.reset_color_selected_frames"
    bl_label = "Reset Selected Frames"
    bl_description = "Remove custom color from selected Frame nodes (Shortcut: Shift+Alt+R)"
    
    @classmethod
    def poll(cls, context):
        return context.selected_nodes
    
    def execute(self, context):
        for node in context.selected_nodes:
            if node.bl_idname == 'NodeFrame':
                node.use_custom_color = False
                if 'sfc_colored' in node:
                    del node['sfc_colored']
        return {'FINISHED'}

class SFC_OT_ResetColorAllFrames(Operator):
    """Removes custom color from all Frame nodes in the tree."""
    bl_idname = "sfc.reset_color_all_frames"
    bl_label = "Reset All Frames"
    bl_description = "Remove custom color from all Frame nodes in the tree (Shortcut: Shift+Alt+X)"

    @classmethod
    def poll(cls, context):
        space = context.space_data
        return space and space.type == 'NODE_EDITOR' and space.node_tree

    def execute(self, context):
        tree = context.space_data.node_tree
        for node in tree.nodes:
            if node.bl_idname == 'NodeFrame':
                node.use_custom_color = False
                if 'sfc_colored' in node:
                    del node['sfc_colored']
        return {'FINISHED'}

class SFC_OT_AddNodeRule(Operator):
    bl_idname = "sfc.add_node_rule"; bl_label = "Add Node Rule"
    bl_description = "Add a new node-based coloring rule"
    def execute(self, context):
        prefs = get_prefs(context)
        prefs.node_rules.add()
        prefs.active_node_rule_index = len(prefs.node_rules) - 1
        return {'FINISHED'}

class SFC_OT_RemoveNodeRule(Operator):
    bl_idname = "sfc.remove_node_rule"; bl_label = "Remove Node Rule"
    bl_description = "Remove the selected node-based coloring rule"
    def execute(self, context):
        prefs = get_prefs(context)
        i = prefs.active_node_rule_index
        if 0 <= i < len(prefs.node_rules):
            prefs.node_rules.remove(i)
            prefs.active_node_rule_index = max(0, i - 1)
        return {'FINISHED'}

class SFC_OT_AddKeywordRule(Operator):
    bl_idname = "sfc.add_keyword_rule"; bl_label = "Add Keyword Rule"
    bl_description = "Add a new keyword-based coloring rule"
    def execute(self, context):
        prefs = get_prefs(context)
        prefs.keyword_rules.add()
        prefs.active_keyword_rule_index = len(prefs.keyword_rules) - 1
        return {'FINISHED'}

class SFC_OT_RemoveKeywordRule(Operator):
    bl_idname = "sfc.remove_keyword_rule"; bl_label = "Remove Keyword Rule"
    bl_description = "Remove the selected keyword-based coloring rule"
    def execute(self, context):
        prefs = get_prefs(context)
        i = prefs.active_keyword_rule_index
        if 0 <= i < len(prefs.keyword_rules):
            prefs.keyword_rules.remove(i)
            prefs.active_keyword_rule_index = max(0, i - 1)
        return {'FINISHED'}

class SFC_OT_AddPalette(Operator):
    bl_idname = "sfc.add_palette"; bl_label = "Add Palette"
    bl_description = "Create a new color palette"
    def execute(self, context):
        prefs = get_prefs(context)
        pal = prefs.palettes.add()
        pal.name = "New Palette"
        c1 = pal.colors.add(); c1.color = (1, 1, 1); c1.position = 0.0
        c2 = pal.colors.add(); c2.color = (0, 0, 0); c2.position = 1.0
        prefs.active_palette_index = len(prefs.palettes) - 1
        return {'FINISHED'}

class SFC_OT_RemovePalette(Operator):
    bl_idname = "sfc.remove_palette"; bl_label = "Remove Palette"
    bl_description = "Delete the selected color palette"
    def execute(self, context):
        prefs = get_prefs(context)
        i = prefs.active_palette_index
        if 0 <= i < len(prefs.palettes):
            prefs.palettes.remove(i)
            prefs.active_palette_index = max(0, i - 1)
        return {'FINISHED'}

class SFC_OT_AddPaletteColor(Operator):
    bl_idname = "sfc.add_palette_color"; bl_label = "Add Palette Color"
    bl_description = "Add a new color to the current palette"
    def execute(self, context):
        prefs = get_prefs(context)
        pal = prefs.palettes[prefs.active_palette_index]
        c = pal.colors.add()
        c.color = (0.5, 0.5, 0.5); c.weight = 1.0; c.position = 0.5
        pal.active_color_index = len(pal.colors) - 1
        return {'FINISHED'}

class SFC_OT_RemovePaletteColor(Operator):
    bl_idname = "sfc.remove_palette_color"; bl_label = "Remove Color from Palette"; index: IntProperty()
    bl_description = "Remove this color from the current palette"
    def execute(self, context):
        prefs = get_prefs(context)
        pal = prefs.palettes[prefs.active_palette_index]
        if 0 <= self.index < len(pal.colors):
            pal.colors.remove(self.index)
            pal.active_color_index = max(0, min(self.index - 1, len(pal.colors) - 1))
        return {'FINISHED'}

class SFC_OT_SortPaletteColors(Operator):
    bl_idname = "sfc.sort_palette_colors"; bl_label = "Sort Palette Colors"
    bl_description = "Sort color stops by position for Gradient mode"
    def execute(self, context):
        prefs = get_prefs(context)
        pal = prefs.palettes[prefs.active_palette_index]
        sorted_data = sorted([(c.color, c.position, c.weight) for c in pal.colors], key=lambda x: x[1])
        pal.colors.clear()
        for color, position, weight in sorted_data:
            new_c = pal.colors.add()
            new_c.color = color; new_c.position = position; new_c.weight = weight
        return {'FINISHED'}

class SFC_OT_LoadConfig(Operator):
    bl_idname = "sfc.load_config"; bl_label = "Load Config"
    bl_description = "Load palettes and rules from a JSON file"
    def execute(self, context):
        prefs = get_prefs(context)
        path = bpy.path.abspath(prefs.json_path)
        try:
            json_io.import_config(path, prefs)
            self.report({'INFO'}, "Configuration loaded successfully")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to load JSON: {e}")
            return {'CANCELLED'}
        return {'FINISHED'}

class SFC_OT_SaveConfig(Operator):
    bl_idname = "sfc.save_config"; bl_label = "Save Config"
    bl_description = "Save palettes and rules to a JSON file"
    filepath: StringProperty(subtype='FILE_PATH')

    def invoke(self, context, event):
        prefs = get_prefs(context)
        if prefs.json_path: self.filepath = bpy.path.abspath(prefs.json_path)
        elif bpy.data.is_saved:
            blend_name = bpy.path.display_name_from_filepath(bpy.data.filepath)
            self.filepath = bpy.path.abspath(f"//{blend_name}_sfc_config.json")
        else: self.filepath = "sfc_config.json"
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    
    def execute(self, context):
        prefs = get_prefs(context)
        try:
            json_io.export_config(self.filepath, prefs)
            prefs.json_path = bpy.path.relpath(self.filepath)
            self.report({'INFO'}, f"Saved to {self.filepath}")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to save JSON: {e}")
            return {'CANCELLED'}
        return {'FINISHED'}

classes = (
    SFC_OT_MovePaletteColor,
    SFC_OT_ApplyQuickColor, SFC_OT_ApplyColorAllFrames, SFC_OT_ApplyColorSelectedFrames,
    SFC_OT_ResetColorSelectedFrames, SFC_OT_ResetColorAllFrames,
    SFC_OT_AddNodeRule, SFC_OT_RemoveNodeRule, SFC_OT_AddKeywordRule, SFC_OT_RemoveKeywordRule,
    SFC_OT_AddPalette, SFC_OT_RemovePalette, SFC_OT_AddPaletteColor, SFC_OT_RemovePaletteColor,
    SFC_OT_SortPaletteColors, SFC_OT_LoadConfig, SFC_OT_SaveConfig,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass