# json_io.py

import json
import bpy

def export_config(filepath, prefs):
    """Exports the addon's rules and palettes to a JSON file."""
    data = {"palettes": [], "node_rules": [], "keyword_rules": []}
    
    for p in prefs.palettes:
        pd = {"name": p.name, "sampling_mode": p.sampling_mode, "gradient_interpolation": p.gradient_interpolation, "colors": []}
        for c in p.colors:
            pd["colors"].append({"color": list(c.color), "weight": c.weight, "position": c.position})
        data["palettes"].append(pd)
        
    for nr in prefs.node_rules:
        data["node_rules"].append({
            "node_type": nr.node_type, "mode": nr.mode,
            "color": list(nr.color), "palette_name": nr.palette_name
        })
        
    for kr in prefs.keyword_rules:
        data["keyword_rules"].append({
            "label": kr.label, "mode": kr.mode,
            "color": list(kr.color), "palette_name": kr.palette_name
        })
        
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

def import_config(filepath, prefs):
    """Imports rules and palettes from a JSON file, overwriting current settings."""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        raise Exception(f"File not found: {filepath}")
    except json.JSONDecodeError:
        raise Exception("File is not a valid JSON.")

    prefs.palettes.clear()
    prefs.node_rules.clear()
    prefs.keyword_rules.clear()

    for pd in data.get("palettes", []):
        p = prefs.palettes.add()
        p.name = pd.get("name", "Unnamed Palette")
        p.sampling_mode = pd.get("sampling_mode", "UNIFORM")
        p.gradient_interpolation = pd.get("gradient_interpolation", "LINEAR")
        p.colors.clear()
        for cd in pd.get("colors", []):
            c = p.colors.add()
            c.color = tuple(cd.get("color", [1, 1, 1]))
            c.weight = cd.get("weight", 1.0)
            c.position = cd.get("position", 0.0)
    
    for nd in data.get("node_rules", []):
        nr = prefs.node_rules.add()
        nr.node_type = nd.get("node_type", "")
        nr.mode = nd.get("mode", "SINGLE")
        nr.color = tuple(nd.get("color", [0.5, 0.5, 0.5]))
        nr.palette_name = nd.get("palette_name", "")
        
    for kd in data.get("keyword_rules", []):
        kr = prefs.keyword_rules.add()
        kr.label = kd.get("label", "")
        kr.mode = kd.get("mode", "SINGLE")
        kr.color = tuple(kd.get("color", [1.0, 1.0, 1.0]))
        kr.palette_name = kd.get("palette_name", "")