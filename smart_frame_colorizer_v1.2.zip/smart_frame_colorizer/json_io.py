# json_io.py

import json
import bpy

def export_config(filepath, prefs):
    """Exports the addon's rules and palettes to a JSON file."""
    # Start with an empty structure for the new unified rules list
    data = {"palettes": [], "rules": []}
    
    # Export palettes (unchanged)
    for p in prefs.palettes:
        pd = {
            "name": p.name, 
            "sampling_mode": p.sampling_mode, 
            "gradient_interpolation": p.gradient_interpolation, 
            "colors": []
        }
        for c in p.colors:
            pd["colors"].append({
                "color": list(c.color), 
                "weight": c.weight, 
                "position": c.position
            })
        data["palettes"].append(pd)
        
    # NEW: Export the single, unified rules list
    for r in prefs.rules:
        data["rules"].append({
            "rule_type": r.rule_type,
            "keyword": r.keyword,
            "node_type": r.node_type,
            "mode": r.mode,
            "color": list(r.color),
            "palette_name": r.palette_name
        })
        
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

def import_config(filepath, prefs):
    """Imports rules and palettes from a JSON file, overwriting current settings."""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        raise Exception(f"File not found: {filepath}")
    except json.JSONDecodeError:
        raise Exception("File is not a valid JSON.")

    # Clear existing data
    prefs.palettes.clear()
    prefs.rules.clear() # Clear the new unified list

    # Import palettes (unchanged)
    for pd in data.get("palettes", []):
        p = prefs.palettes.add()
        p.name = pd.get("name", "Unnamed Palette")
        p.sampling_mode = pd.get("sampling_mode", "UNIFORM")
        p.gradient_interpolation = pd.get("gradient_interpolation", "LINEAR")
        for cd in pd.get("colors", []):
            c = p.colors.add()
            c.color = tuple(cd.get("color", [1, 1, 1]))
            c.weight = cd.get("weight", 1.0)
            c.position = cd.get("position", 0.0)
    
    # NEW: Import into the single, unified rules list from the "rules" key
    for rd in data.get("rules", []):
        r = prefs.rules.add()
        r.rule_type = rd.get("rule_type", "NODE_TYPE")
        r.keyword = rd.get("keyword", "")
        r.node_type = rd.get("node_type", "ShaderNodeBsdfPrincipled")
        r.mode = rd.get("mode", "SINGLE")
        r.color = tuple(rd.get("color", [0.5, 0.5, 0.5]))
        r.palette_name = rd.get("palette_name", "")

    # This part handles importing OLD config files for backward compatibility
    # It checks for the old keys and converts them to the new unified format.
    if "node_rules" in data or "keyword_rules" in data:
        for nd in data.get("node_rules", []):
            nr = prefs.rules.add()
            nr.rule_type = "NODE_TYPE"
            nr.node_type = nd.get("node_type", "")
            nr.mode = nd.get("mode", "SINGLE")
            nr.color = tuple(nd.get("color", [0.5, 0.5, 0.5]))
            nr.palette_name = nd.get("palette_name", "")
            
        for kd in data.get("keyword_rules", []):
            kr = prefs.rules.add()
            kr.rule_type = "KEYWORD"
            kr.keyword = kd.get("label", "") # Use "label" key from old format
            kr.mode = kd.get("mode", "SINGLE")
            kr.color = tuple(kd.get("color", [1.0, 1.0, 1.0]))
            kr.palette_name = kd.get("palette_name", "")