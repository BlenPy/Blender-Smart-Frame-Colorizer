# storage.py

def get_palette_by_name(prefs, name):
    """Finds and returns a palette by its name."""
    for p in prefs.palettes:
        if p.name == name:
            return p
    return None
