# preferences.py

import bpy
from bpy.props import (
    BoolProperty, EnumProperty, StringProperty,
    CollectionProperty, IntProperty,
    FloatVectorProperty, FloatProperty
)
from bpy.types import AddonPreferences, PropertyGroup, UIList

# --- Helper Functions and Property Groups (unchanged) ---
def get_palette_enum_items(self, context):
    prefs = context.preferences.addons[__package__].preferences
    if not prefs.palettes:
        return [("NONE", "No Palettes Available", "Create a palette first in the Palettes section")]
    return [(p.name, p.name, f"Use the '{p.name}' palette") for p in prefs.palettes]

def get_all_shader_node_types(self, context):
    items = []
    for name in dir(bpy.types):
        cls = getattr(bpy.types, name)
        if isinstance(cls, type) and issubclass(cls, bpy.types.ShaderNode) and cls is not bpy.types.ShaderNode:
            try: items.append((cls.bl_rna.identifier, cls.bl_rna.name, ""))
            except AttributeError: continue
    return sorted(items, key=lambda x: x[1])

class SFC_PaletteColorItem(PropertyGroup):
    color: FloatVectorProperty(name="Color", subtype='COLOR', size=3, min=0.0, max=1.0, default=(1.0, 1.0, 1.0), description="The color swatch")
    position: FloatProperty(name="Position", description="Position on the gradient (0-1)", default=0.0, min=0.0, max=1.0, subtype='FACTOR')
    weight: FloatProperty(name="Weight", description="Probability weight for this color in 'Weighted Random' mode (0-100%)", default=1.0, min=0.0, max=100.0)

class SFC_PaletteItem(PropertyGroup):
    name: StringProperty(name="Palette Name", default="New Palette", description="A unique name for this palette")
    sampling_mode: EnumProperty(name="Sampling Mode", items=[("UNIFORM", "Uniform Random", "Each color has an equal chance"), ("WEIGHTED", "Weighted Random", "Chance is based on color weight"), ("GRADIENT", "Gradient", "Interpolates colors like a Color Ramp"), ("SEQUENTIAL", "Sequential", "Cycles through colors in order")], default="UNIFORM", description="How colors are chosen from this palette")
    gradient_interpolation: EnumProperty(name="Interpolation", items=[('LINEAR', "Linear", "Linear interpolation"), ('EASE', "Ease", "Ease interpolation")], default="LINEAR", description="The interpolation method for 'Gradient' mode")
    colors: CollectionProperty(type=SFC_PaletteColorItem)
    active_color_index: IntProperty(default=0)

class SFC_RuleItem(PropertyGroup):
    name: StringProperty(name="Name", default="New Rule")
    rule_type: EnumProperty(name="Rule Type", items=[('NODE_TYPE', "Node Type", ""), ('KEYWORD', "Keyword", "")], default='NODE_TYPE', description="The type of condition to check for this rule")
    keyword: StringProperty(name="Keyword", default="Keyword", description="The text to search for in a frame's label")
    node_type: EnumProperty(name="Node Type", items=get_all_shader_node_types, description="The node type to search for inside a frame")
    mode: EnumProperty(name="Mode", items=[("SINGLE", "Single Color", ""), ("PALETTE", "Use Palette", "")], default="SINGLE", description="What to do when this rule is matched")
    color: FloatVectorProperty(name="Color", subtype='COLOR', size=3, min=0.0, max=1.0, default=(0.5, 0.5, 0.5), description="The color to apply")
    palette_name: EnumProperty(name="Palette", description="The palette to use", items=get_palette_enum_items)

class SFC_UL_PaletteColors(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        pal, sw = data, item; row = layout.row(); row.prop(sw, "color", text="")
        if pal.sampling_mode == "WEIGHTED": row.prop(sw, "weight", text="")
        elif pal.sampling_mode == "GRADIENT": row.prop(sw, "position", slider=True, text="")
class SFC_UL_Rules(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if item.rule_type == 'NODE_TYPE':
            label = item.node_type.replace("ShaderNode", "")
            icon = 'NODE'
        else:
            label = f'"{item.keyword}"'
            icon = 'FONT_DATA'
        layout.label(text=label, icon=icon)
class SFC_UL_Palettes(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index): layout.label(text=item.name, icon='GROUP_VCOL')

class SFC_Preferences(AddonPreferences):
    bl_idname = __name__.split(".")[0]

    active_tab: EnumProperty(items=[('SETTINGS', "Settings", ""), ('RULES', "Rules", ""), ('PALETTES', "Palettes", "")], default='SETTINGS')
    auto_color: BoolProperty(name="Auto Color", default=True)
    color_mode: EnumProperty(name="Color Mode", items=[("RANDOM", "Random", ""), ("RULES", "By Rules", "")], default="RULES")
    fallback_random: BoolProperty(name="Fallback to Random", default=True)
    json_path: StringProperty(name="Config File Path", subtype='FILE_PATH')
    developer_mode: BoolProperty(name="Developer Mode", default=False)
    
    palettes: CollectionProperty(type=SFC_PaletteItem)
    active_palette_index: IntProperty(default=0)
    rules: CollectionProperty(type=SFC_RuleItem)
    active_rule_index: IntProperty(default=0)

    def draw_rules_tab(self, context, layout):
        col = layout.column()
        col.label(text="Rules", icon="SCRIPTPLUGINS")
        
        row = col.row()
        row.template_list("SFC_UL_Rules", "", self, "rules", self, "active_rule_index")
        
        col_buttons = row.column(align=True)
        col_buttons.operator("sfc.add_rule", icon="ADD", text="")
        col_buttons.operator("sfc.remove_rule", icon="REMOVE", text="")
        col_buttons.separator()
        op_up = col_buttons.operator("sfc.move_rule", icon='TRIA_UP', text="")
        op_up.direction = 'UP'
        op_down = col_buttons.operator("sfc.move_rule", icon='TRIA_DOWN', text="")
        op_down.direction = 'DOWN'
        
        col.separator()

        if self.rules:
            rule = self.rules[self.active_rule_index]
            col.label(text="Edit Rule")
            col.prop(rule, "rule_type", text="")
            
            # THE FIX: Correct variable name
            col.separator() 
            if rule.rule_type == 'NODE_TYPE':
                col.prop(rule, "node_type", text="")
            else:
                col.prop(rule, "keyword", text="")
            
            col.separator() 
            col.prop(rule, "mode", text="")
            
            # THE FIX: Correct variable name
            col.separator() 
            if rule.mode == 'SINGLE':
                col.prop(rule, "color", text="")
            else:
                col.prop(rule, "palette_name", text="")

    def draw_palettes_tab(self, context, layout):
        col_main = layout.column()
        col_main.label(text="Palettes")
        row_list = col_main.row()
        row_list.template_list("SFC_UL_Palettes", "", self, "palettes", self, "active_palette_index")
        col_buttons_list = row_list.column(align=True)
        col_buttons_list.operator("sfc.add_palette", icon="ADD", text="")
        col_buttons_list.operator("sfc.remove_palette", icon="REMOVE", text="")

        if not self.palettes: return
        col_main.separator()

        pal = self.palettes[self.active_palette_index]
        split_editor = col_main.split(factor=0.5)
        
        left_col = split_editor.column()
        left_col.label(text="Edit Palette")
        left_col.prop(pal, "name", text="")
        # THE FIX: Correct variable name
        left_col.separator() 
        left_col.prop(pal, "sampling_mode", text="")
        # THE FIX: Correct variable name
        left_col.separator() 
        if pal.sampling_mode == "GRADIENT": left_col.prop(pal, "gradient_interpolation", text="")
        elif pal.sampling_mode == "WEIGHTED":
            # THE FIX: Correct variable name
            left_col.separator() 
            total = sum(c.weight for c in pal.colors)
            icon = 'CHECKMARK' if abs(total - 100.0) < 0.01 else 'ERROR'
            left_col.label(text=f"Total Weight: {total:.1f}/100", icon=icon)

        right_col = split_editor.column()
        right_col.label(text="Colors")
        row_colors = right_col.row()
        row_colors.template_list("SFC_UL_PaletteColors", "", pal, "colors", pal, "active_color_index")
        col_color_buttons = row_colors.column(align=True)
        col_color_buttons.operator("sfc.add_palette_color", icon="ADD", text="")
        op_rem = col_color_buttons.operator("sfc.remove_palette_color", icon="REMOVE", text=""); op_rem.index = pal.active_color_index
        col_color_buttons.separator()
        row_up = col_color_buttons.row(align=True); row_up.enabled = pal.active_color_index > 0
        op_up = row_up.operator("sfc.move_palette_color", icon='TRIA_UP', text=""); op_up.direction = 'UP'
        row_down = col_color_buttons.row(align=True); row_down.enabled = pal.active_color_index < len(pal.colors) - 1
        op_down = row_down.operator("sfc.move_palette_color", icon='TRIA_DOWN', text=""); op_down.direction = 'DOWN'
        
        if self.developer_mode:
            dev_box = layout.box()
            dev_box.label(text="Developer Tools", icon="SETTINGS")
            row_dev = dev_box.row(); row_dev.enabled = bool(pal.colors)
            row_dev.operator("sfc.test_palette", text="Test Distribution", icon='IMAGE_DATA')

    def draw_settings_tab(self, context, layout):
        col = layout.column()
        col.label(text="General Behavior", icon="PRESET")
        col.prop(self, "auto_color")
        if self.color_mode == "RULES": col.prop(self, "fallback_random")
        col.separator()
        col.label(text="Config Import/Export", icon="FILE_FOLDER")
        col_config = col.column(); col_config.enabled = self.color_mode == 'RULES' 
        col_config.prop(self, "json_path", text="")
        row = col_config.row(align=True)
        row.operator("sfc.load_config", text="Load", icon="FILE_REFRESH")
        row.operator("sfc.save_config", text="Save", icon="FILE_TICK")

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "color_mode")
        layout.separator()
        row = layout.row(); row.prop(self, "active_tab", expand=True)
        main_col = layout.column()
        is_rules_mode = self.color_mode == 'RULES'
        if self.active_tab == 'RULES':
            if not is_rules_mode: main_col.label(text="Rules are only available in 'By Rules' mode.", icon='INFO')
            else: self.draw_rules_tab(context, main_col)
        elif self.active_tab == 'PALETTES':
            if not is_rules_mode: main_col.label(text="Palettes are only available in 'By Rules' mode.", icon='INFO')
            else: self.draw_palettes_tab(context, main_col)
        elif self.active_tab == 'SETTINGS':
            self.draw_settings_tab(context, main_col)

classes = (
    SFC_PaletteColorItem, SFC_PaletteItem, 
    SFC_RuleItem,
    SFC_UL_PaletteColors, 
    SFC_UL_Rules,
    SFC_UL_Palettes, 
    SFC_Preferences,
)

def register():
    for cls in classes: bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        try: bpy.utils.unregister_class(cls)
        except RuntimeError: pass