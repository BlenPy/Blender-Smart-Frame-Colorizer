import bpy
import json
from bpy.props import (
    BoolProperty,
    EnumProperty,
    StringProperty,
    CollectionProperty,
    IntProperty,
    FloatVectorProperty,
)
from bpy.types import AddonPreferences, PropertyGroup, UIList

# ───────────────────────────────────────────────────────────────
# (1) Gather all ShaderNode types by scanning bpy.types
# ───────────────────────────────────────────────────────────────
def get_all_shader_node_types(self, context):
    items = []
    for attr_name in dir(bpy.types):
        cls = getattr(bpy.types, attr_name)
        if isinstance(cls, type) and issubclass(cls, bpy.types.ShaderNode) and cls is not bpy.types.ShaderNode:
            try:
                identifier = cls.bl_rna.identifier
                name = cls.bl_rna.name
                items.append((identifier, name, ""))
            except:
                continue
    items.sort(key=lambda x: x[1])

    # Debug print (visible if Blender is run from Terminal)
    print("[SFC] get_all_shader_node_types called")
    print(f"[SFC]   Found {len(items)} shader-node entries:")
    for i, (nid, label, _) in enumerate(items[:8]):
        print(f"[SFC]     {i+1}: {label} ({nid})")
    if len(items) > 8:
        print(f"[SFC]     ... plus {len(items)-8} more items")

    return items


# ───────────────────────────────────────────────────────────────
# (2) A single color in a palette
# ───────────────────────────────────────────────────────────────
class SFC_PaletteColorItem(PropertyGroup):
    color: FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0),
    )


# ───────────────────────────────────────────────────────────────
# (3) A palette: name + list of SFC_PaletteColorItem
# ───────────────────────────────────────────────────────────────
class SFC_PaletteItem(PropertyGroup):
    name: StringProperty(name="Palette Name", default="New Palette")
    colors: CollectionProperty(type=SFC_PaletteColorItem)
    active_color_index: IntProperty(default=0)


# ───────────────────────────────────────────────────────────────
# (4) A Node‐Based rule: pick a ShaderNode type + single color or palette name
# ───────────────────────────────────────────────────────────────
class SFC_NodeRuleItem(PropertyGroup):
    node_type: EnumProperty(
        name="Node Type",
        items=get_all_shader_node_types,
    )
    mode: EnumProperty(
        name="Mode",
        items=[
            ("SINGLE", "Single Color", "Use a single RGB color"),
            ("PALETTE", "Palette",      "Use a color from a named palette"),
        ],
        default="SINGLE",
    )
    color: FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(0.5, 0.5, 0.5),
    )
    palette_name: StringProperty(name="Palette Name", default="")


# ───────────────────────────────────────────────────────────────
# (5) A Keyword‐Based rule: match substring in frame label + color/palette
# ───────────────────────────────────────────────────────────────
class SFC_KeywordRuleItem(PropertyGroup):
    label: StringProperty(name="Label Keyword", default="AO")
    mode: EnumProperty(
        name="Mode",
        items=[
            ("SINGLE", "Single Color", "Use a single RGB color"),
            ("PALETTE", "Palette",      "Use a color from a named palette"),
        ],
        default="SINGLE",
    )
    color: FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(0.3, 0.6, 1.0),
    )
    palette_name: StringProperty(name="Palette Name", default="")


# ───────────────────────────────────────────────────────────────
# (6) UIList for Node‐Based rules (shows short node names)
# ───────────────────────────────────────────────────────────────
class SFC_UL_NodeRules(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            short_name = item.node_type.replace("ShaderNode", "")
            layout.label(text=short_name, icon='NODE')
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon='NODE')


# ───────────────────────────────────────────────────────────────
# (7) UIList for Keyword‐Based rules (shows each label as plain text)
# ───────────────────────────────────────────────────────────────
class SFC_UL_KeywordRules(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.label(text=item.label, icon='FONT_DATA')
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon='FONT_DATA')


# ───────────────────────────────────────────────────────────────
# (8) Main Preferences Panel
# ───────────────────────────────────────────────────────────────
class SFC_Preferences(AddonPreferences):
    bl_idname = __name__.split(".")[0]  # must match addon folder name

    # ─────────────────────────────────────────────────────────────
    # A) General Settings
    # ─────────────────────────────────────────────────────────────
    auto_color: BoolProperty(
        name="Auto Color on Frame Creation",
        description="Automatically assign a color when a new frame is added",
        default=True,
    )

    color_mode: EnumProperty(
        name="Color Mode",
        description="Choose how frames should be colored",
        items=[
            ("RANDOM", "Random", "Assign random colors"),
            ("RULES",  "By Rules", "Use node or keyword rules"),
        ],
        default="RANDOM",
    )

        # ─── Fallback Random toggle ───
    fallback_random: BoolProperty(
        name="Fallback Random Color",
        description="If no rule matches in RULES mode, assign a one-time random tint",
        default=True,
    )

    # ─────────────────────────────────────────────────────────────
    # B) JSON Import/Export Path
    # ─────────────────────────────────────────────────────────────
    json_path: StringProperty(
        name="Palette / Rule File Path",
        description="Path to a JSON file containing user palettes & rules",
        subtype='FILE_PATH',
        default="",
    )

    palettes: CollectionProperty(type=SFC_PaletteItem)
    active_palette_index: IntProperty(name="Active Palette", default=0)

    node_rules: CollectionProperty(type=SFC_NodeRuleItem)
    active_node_rule_index: IntProperty(name="Active Node Rule", default=0)

    keyword_rules: CollectionProperty(type=SFC_KeywordRuleItem)
    active_keyword_rule_index: IntProperty(name="Active Keyword Rule", default=0)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Smart Frame Colorizer Settings", icon="COLOR")
        layout.use_property_split = True
        layout.use_property_decorate = False

        # ────────────────────────────────
        # A) Coloring Behavior
        # ────────────────────────────────
        box = layout.box()
        box.label(text="Coloring Behavior", icon="PRESET")
        box.prop(self, "auto_color")
        box.prop(self, "color_mode")

        if self.color_mode == "RANDOM":
            return

        # ────────────────────────────────
        # B) Palette / Rule Import/Export
        # ────────────────────────────────
        box = layout.box()
        box.label(text="Palette / Rule Import", icon="FILE_FOLDER")
        box.prop(self, "json_path")

        row = box.row(align=True)
        row.operator("sfc.load_config", text="Load", icon="FILE_REFRESH")
        row.operator("sfc.save_config", text="Save", icon="FILE_TICK")

        if self.json_path:
            try:
                with open(bpy.path.abspath(self.json_path), 'r') as f:
                    json.load(f)
            except Exception as e:
                layout.label(text="Error loading JSON (see console)", icon="ERROR")
                print("[Smart Frame Colorizer] JSON load error:", e)

        # ─── Fallback Random for RULES mode ───
        if self.color_mode == "RULES":
            row = layout.row()
            row.prop(self, "fallback_random")

        # ────────────────────────────────
        # C) Node‐Based Rules Editor
        # ────────────────────────────────
        box = layout.box()
        box.label(text="Node‐Based Rules", icon="NODE")
        row = box.row()
        row.template_list(
            "SFC_UL_NodeRules", "", 
            self, "node_rules", 
            self, "active_node_rule_index"
        )

        col = row.column(align=True)
        col.operator("sfc.add_node_rule", text="", icon="ADD")
        col.operator("sfc.remove_node_rule", text="", icon="REMOVE")

        if self.node_rules and 0 <= self.active_node_rule_index < len(self.node_rules):
            rule = self.node_rules[self.active_node_rule_index]
            box.prop(rule, "node_type")
            box.prop(rule, "mode")
            if rule.mode == 'SINGLE':
                box.prop(rule, "color")
            else:
                box.prop(rule, "palette_name")

        # ────────────────────────────────
        # D) Keyword‐Based Rules Editor
        # ────────────────────────────────
        box = layout.box()
        box.label(text="Keyword‐Based Rules", icon="FONT_DATA")
        row = box.row()
        row.template_list(
            "SFC_UL_KeywordRules", "", 
            self, "keyword_rules", 
            self, "active_keyword_rule_index"
        )

        col = row.column(align=True)
        col.operator("sfc.add_keyword_rule", text="", icon="ADD")
        col.operator("sfc.remove_keyword_rule", text="", icon="REMOVE")

        if self.keyword_rules and 0 <= self.active_keyword_rule_index < len(self.keyword_rules):
            rule = self.keyword_rules[self.active_keyword_rule_index]
            box.prop(rule, "label")
            box.prop(rule, "mode")
            if rule.mode == 'SINGLE':
                box.prop(rule, "color")
            else:
                box.prop(rule, "palette_name")

        # ────────────────────────────────
        # E) Palette Editor (Preview)
        # ────────────────────────────────
        box = layout.box()
        box.label(text="Palette Editor (Preview)", icon="COLOR")

        row = box.row(align=True)
        # Use a plain Int index rather than prop_search
        row.prop(self, "active_palette_index", text="Palette")
        row.operator("sfc.add_palette", text="", icon="ADD")
        row.operator("sfc.remove_palette", text="", icon="REMOVE")

        if len(self.palettes) > 0 and 0 <= self.active_palette_index < len(self.palettes):
            selected = self.palettes[self.active_palette_index]
            box.prop(selected, "name")
            for i, color_item in enumerate(selected.colors):
                row = box.row(align=True)
                row.prop(color_item, "color", text="", emboss=True)
                op = row.operator("sfc.remove_palette_color", text="", icon="X")
                op.index = i
            box.operator("sfc.add_palette_color", icon="ADD")


# ───────────────────────────────────────────────────────────────
# (9) REGISTER / UNREGISTER ALL CLASSES
# ───────────────────────────────────────────────────────────────
classes = [
    SFC_PaletteColorItem,
    SFC_PaletteItem,
    SFC_NodeRuleItem,
    SFC_KeywordRuleItem,
    SFC_UL_NodeRules,
    SFC_UL_KeywordRules,
    SFC_Preferences,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.sfc_palettes = CollectionProperty(type=SFC_PaletteItem)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.WindowManager.sfc_palettes