import bpy
import os
import random
from bpy.types import Operator
from bpy.props import IntProperty

# JSON import/export helper
from . import json_io

# Frame‐color logic functions
from .logic import pick_color_for_frame, apply_color_to_frame

# PropertyGroup types for type hints (not registered here)
from .preferences import (
    SFC_NodeRuleItem,
    SFC_KeywordRuleItem,
    SFC_PaletteItem,
    SFC_PaletteColorItem,
    SFC_Preferences,
)


# ───────────────────────────────────────────────────────────────
# (1) Add / Remove Node‐Based Rule
# ───────────────────────────────────────────────────────────────
class SFC_OT_AddNodeRule(Operator):
    bl_idname = "sfc.add_node_rule"
    bl_label = "Add Node Rule"
    bl_description = "Add a new node‐based coloring rule"

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        new_rule = prefs.node_rules.add()
        new_rule.mode = 'SINGLE'
        new_rule.color = (0.5, 0.5, 0.5)
        prefs.active_node_rule_index = len(prefs.node_rules) - 1
        return {'FINISHED'}


class SFC_OT_RemoveNodeRule(Operator):
    bl_idname = "sfc.remove_node_rule"
    bl_label = "Remove Node Rule"
    bl_description = "Remove the selected node‐based coloring rule"

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        idx = prefs.active_node_rule_index
        if 0 <= idx < len(prefs.node_rules):
            prefs.node_rules.remove(idx)
            prefs.active_node_rule_index = max(0, idx - 1)
        return {'FINISHED'}


# ───────────────────────────────────────────────────────────────
# (2) Add / Remove Keyword‐Based Rule
# ───────────────────────────────────────────────────────────────
class SFC_OT_AddKeywordRule(Operator):
    bl_idname = "sfc.add_keyword_rule"
    bl_label = "Add Keyword Rule"
    bl_description = "Add a new keyword‐based coloring rule"

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        new_rule = prefs.keyword_rules.add()
        new_rule.label = ""
        new_rule.mode = 'SINGLE'
        new_rule.color = (0.5, 0.5, 0.5)
        prefs.active_keyword_rule_index = len(prefs.keyword_rules) - 1
        return {'FINISHED'}


class SFC_OT_RemoveKeywordRule(Operator):
    bl_idname = "sfc.remove_keyword_rule"
    bl_label = "Remove Keyword Rule"
    bl_description = "Remove the selected keyword‐based coloring rule"

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        idx = prefs.active_keyword_rule_index
        if 0 <= idx < len(prefs.keyword_rules):
            prefs.keyword_rules.remove(idx)
            prefs.active_keyword_rule_index = max(0, idx - 1)
        return {'FINISHED'}


# ───────────────────────────────────────────────────────────────
# (3) Add / Remove Palette
# ───────────────────────────────────────────────────────────────
class SFC_OT_AddPalette(Operator):
    bl_idname = "sfc.add_palette"
    bl_label = "Add Palette"
    bl_description = "Create a new color palette"

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        new_pal = prefs.palettes.add()
        new_pal.name = "New Palette"
        color_item = new_pal.colors.add()
        color_item.color = (1.0, 1.0, 1.0)
        prefs.active_palette_index = len(prefs.palettes) - 1
        return {'FINISHED'}


class SFC_OT_RemovePalette(Operator):
    bl_idname = "sfc.remove_palette"
    bl_label = "Remove Palette"
    bl_description = "Delete the selected color palette"

    @classmethod
    def poll(cls, context):
        prefs = context.preferences.addons[__package__].preferences
        return 0 <= prefs.active_palette_index < len(prefs.palettes)

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        idx = prefs.active_palette_index
        prefs.palettes.remove(idx)
        prefs.active_palette_index = max(0, idx - 1)
        return {'FINISHED'}


# ───────────────────────────────────────────────────────────────
# (4) Add / Remove Palette Color (RGB swatch entries)
# ───────────────────────────────────────────────────────────────
class SFC_OT_AddPaletteColor(Operator):
    bl_idname = "sfc.add_palette_color"
    bl_label = "Add Palette Color"
    bl_description = "Add a new color to the current palette"

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        idx = prefs.active_palette_index
        if 0 <= idx < len(prefs.palettes):
            pal = prefs.palettes[idx]
            new_color = pal.colors.add()
            new_color.color = (1.0, 1.0, 1.0)
            pal.active_color_index = len(pal.colors) - 1
        return {'FINISHED'}


class SFC_OT_RemovePaletteColor(Operator):
    bl_idname = "sfc.remove_palette_color"
    bl_label = "Remove Palette Color"
    bl_description = "Remove this color from the current palette"

    index: IntProperty()

    @classmethod
    def poll(cls, context):
        prefs = context.preferences.addons[__package__].preferences
        pal_idx = prefs.active_palette_index
        if 0 <= pal_idx < len(prefs.palettes):
            pal = prefs.palettes[pal_idx]
            return len(pal.colors) > 0
        return False

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        pal = prefs.palettes[prefs.active_palette_index]
        pal.colors.remove(self.index)
        pal.active_color_index = max(0, self.index - 1)
        return {'FINISHED'}


# ───────────────────────────────────────────────────────────────
# (5) Load / Save Config (palettes & rules → JSON)
# ───────────────────────────────────────────────────────────────
class SFC_OT_LoadConfig(Operator):
    bl_idname = "sfc.load_config"
    bl_label = "Load Config"
    bl_description = "Load palettes and rules from a JSON file"

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        path = bpy.path.abspath(prefs.json_path)
        try:
            json_io.import_config(path, prefs)
            self.report({'INFO'}, "Configuration loaded successfully")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to load JSON: {e}")
            return {'CANCELLED'}


class SFC_OT_SaveConfig(Operator):
    bl_idname = "sfc.save_config"
    bl_label = "Save Config"
    bl_description = "Save palettes and rules to a JSON file"

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        path = bpy.path.abspath(prefs.json_path)
        try:
            json_io.export_config(path, prefs)
            self.report({'INFO'}, "Configuration saved successfully")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to save JSON: {e}")
            return {'CANCELLED'}


# ───────────────────────────────────────────────────────────────
# (6) Manual “Color Selected” and “Color All” Operators
# ───────────────────────────────────────────────────────────────
class SFC_OT_ApplyColorAllFrames(Operator):
    bl_idname = "sfc.apply_color_all_frames"
    bl_label = "Color All Frames"
    bl_description = "Manually apply coloring rules or random colors to every Frame in the active Shader Editor"

    @classmethod
    def poll(cls, context):
        space = context.space_data
        return (
            space
            and space.type == 'NODE_EDITOR'
            and space.node_tree
            and space.node_tree.bl_idname == 'ShaderNodeTree'
        )

    def execute(self, context):
        prefs: SFC_Preferences = context.preferences.addons[__package__].preferences
        node_tree = context.space_data.node_tree

        for node in node_tree.nodes:
            if node.bl_idname != 'NodeFrame':
                continue

            # RANDOM mode: color once
            if prefs.color_mode == "RANDOM":
                if node.get("sfc_colored", False):
                    continue
                col = (random.random(), random.random(), random.random())
                apply_color_to_frame(node, col)
                node["sfc_colored"] = True
                continue

            # RULES mode with fallback
            if prefs.color_mode == "RULES":
                chosen = pick_color_for_frame(node, prefs)

                if chosen is not None:
                    # Rule matched → color
                    apply_color_to_frame(node, chosen)
                    node["sfc_colored"] = True

                else:
                    # No rule matched → fallback?
                    if prefs.fallback_random:
                        # Always color on manual-run (even if already tagged)
                        col = (random.random(), random.random(), random.random())
                        apply_color_to_frame(node, col)
                        node["sfc_colored"] = True
                continue

        return {'FINISHED'}


class SFC_OT_ApplyColorSelectedFrames(Operator):
    bl_idname = "sfc.apply_color_selected_frames"
    bl_label = "Color Selected Frame(s)"
    bl_description = "Manually apply coloring rules or random colors to each selected Frame in the active Shader Editor"

    @classmethod
    def poll(cls, context):
        space = context.space_data
        return (
            space
            and space.type == 'NODE_EDITOR'
            and space.node_tree
            and space.node_tree.bl_idname == 'ShaderNodeTree'
            and context.selected_nodes
        )

    def execute(self, context):
        prefs: SFC_Preferences = context.preferences.addons[__package__].preferences

        for node in context.selected_nodes:
            if node.bl_idname != 'NodeFrame':
                continue

            # RANDOM mode: color once
            if prefs.color_mode == "RANDOM":
                if node.get("sfc_colored", False):
                    continue
                col = (random.random(), random.random(), random.random())
                apply_color_to_frame(node, col)
                node["sfc_colored"] = True
                continue

                # RULES mode with fallback
            if prefs.color_mode == "RULES":
                chosen = pick_color_for_frame(node, prefs)

                if chosen is not None:
                    apply_color_to_frame(node, chosen)
                    node["sfc_colored"] = True

                else:
                    if prefs.fallback_random:
                        col = (random.random(), random.random(), random.random())
                        apply_color_to_frame(node, col)
                        node["sfc_colored"] = True
                continue

        return {'FINISHED'}


# ───────────────────────────────────────────────────────────────
# (7) Register & Unregister All Operator Classes
# ───────────────────────────────────────────────────────────────
classes = (
    SFC_OT_AddNodeRule,
    SFC_OT_RemoveNodeRule,
    SFC_OT_AddKeywordRule,
    SFC_OT_RemoveKeywordRule,
    SFC_OT_AddPalette,
    SFC_OT_RemovePalette,
    SFC_OT_AddPaletteColor,
    SFC_OT_RemovePaletteColor,
    SFC_OT_LoadConfig,
    SFC_OT_SaveConfig,
    SFC_OT_ApplyColorAllFrames,
    SFC_OT_ApplyColorSelectedFrames,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)