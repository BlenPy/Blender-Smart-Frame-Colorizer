import bpy
from bpy.types import Panel

class SFC_PT_ManualColorPanel(Panel):
    bl_label = "Smart Frame Colorizer"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'SFC'

    @classmethod
    def poll(cls, context):
        space = context.space_data
        return (space and space.type == 'NODE_EDITOR' and space.node_tree and space.node_tree.bl_idname == 'ShaderNodeTree')

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__package__].preferences

        # Show a notice if Auto Color is enabled
        if prefs.auto_color:
            layout.label(text="Auto Color is ON", icon='CHECKMARK')
            layout.operator("sfc.apply_color_all_frames", text="Color All Frames (override)")
            layout.operator("sfc.apply_color_selected_frames", text="Color Selected Frame(s) (override)")
        else:
            layout.label(text="Auto Color is OFF", icon='ERROR')
            layout.operator("sfc.apply_color_selected_frames", text="Color Selected Frame(s)")
            layout.operator("sfc.apply_color_all_frames", text="Color All Frames")


classes = [
    SFC_PT_ManualColorPanel
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)