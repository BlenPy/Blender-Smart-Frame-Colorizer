import bpy
import random

from .preferences import (
    SFC_Preferences,
    SFC_NodeRuleItem,
    SFC_KeywordRuleItem,
    SFC_PaletteItem,
    SFC_PaletteColorItem,
)

# ───────────────────────────────────────────────────────────────────────────────
# Timer callback: run our existing handler regularly (to pick up label edits)
# ───────────────────────────────────────────────────────────────────────────────
_timer_handle = None

def _frame_color_timer():
    prefs = bpy.context.preferences.addons[__package__].preferences
    # Only poll in RULES + auto mode
    if prefs.auto_color and prefs.color_mode == "RULES":
        on_node_tree_update(None)
    # Repeat every half-second
    return 0.5

# ────────────────────────────────────────────────────────────────────────────────
# Helper: pick a random (R,G,B) from a given SFC_PaletteItem
# ────────────────────────────────────────────────────────────────────────────────
def get_random_color_from_palette(palette: SFC_PaletteItem):
    if not palette.colors:
        return (0.8, 0.8, 0.8)
    idx = random.randint(0, len(palette.colors) - 1)
    return palette.colors[idx].color[:]


# ────────────────────────────────────────────────────────────────────────────────
# Decide which color to use under RULES mode (keyword first, then node‐based)
# Returns an (R,G,B) tuple, or None if no rule matches
# ────────────────────────────────────────────────────────────────────────────────
def pick_color_for_frame(frame_node: bpy.types.NodeFrame, prefs: SFC_Preferences):
    label_lower = (frame_node.label or "").lower()
    # Keyword rules
    for kr in prefs.keyword_rules:
        if kr.label and kr.label.lower() in label_lower:
            if kr.mode == 'SINGLE':
                return kr.color[:]
            else:
                for pal in prefs.palettes:
                    if pal.name == kr.palette_name:
                        return get_random_color_from_palette(pal)
                return (0.8, 0.8, 0.8)
    # Node rules (child.parent)
    tree = frame_node.id_data
    if tree and hasattr(tree, "nodes"):
        for nr in prefs.node_rules:
            for child in tree.nodes:
                if getattr(child, "parent", None) == frame_node:
                    if child.bl_rna.identifier == nr.node_type:
                        if nr.mode == 'SINGLE':
                            return nr.color[:]
                        else:
                            for pal in prefs.palettes:
                                if pal.name == nr.palette_name:
                                    return get_random_color_from_palette(pal)
                            return (0.8, 0.8, 0.8)
    return None


# ────────────────────────────────────────────────────────────────────────────────
# Force‐on custom color and assign RGB to the Frame
# ────────────────────────────────────────────────────────────────────────────────
def apply_color_to_frame(frame_node: bpy.types.NodeFrame, color_rgb):
    r, g, b = color_rgb
    # Force the “Use Custom Color” on
    try:
        frame_node.use_custom_color = True
    except Exception:
        pass
    # Assign the color (Blender 4.4 expects a 3‐tuple)
    try:
        frame_node.color = (r, g, b)
    except Exception:
        setattr(frame_node, "color", (r, g, b))


# ────────────────────────────────────────────────────────────────────────────────
# Handler: runs on every depsgraph_update_post
# Auto‐colors frames in RANDOM or RULES mode, with immediate recolor on RULES
# ────────────────────────────────────────────────────────────────────────────────
def on_node_tree_update(dummy):
    prefs = bpy.context.preferences.addons[__package__].preferences

    for area in bpy.context.window.screen.areas:
        if area.type != 'NODE_EDITOR':
            continue
        space = area.spaces.active
        if not space.node_tree or space.node_tree.bl_idname != 'ShaderNodeTree':
            continue

        for node in space.node_tree.nodes:
            if node.bl_idname != 'NodeFrame':
                continue

            # RANDOM mode: color **once** on creation
            if prefs.color_mode == "RANDOM" and prefs.auto_color:
                if not node.get("sfc_colored", False):
                    col = (random.random(), random.random(), random.random())
                    apply_color_to_frame(node, col)
                    node["sfc_colored"] = True
                continue

            # ────────── RULES mode with fallback ──────────
            if prefs.color_mode == "RULES" and prefs.auto_color:
                chosen = pick_color_for_frame(node, prefs)

                if chosen is not None:
                    # A matching rule → apply and tag
                    apply_color_to_frame(node, chosen)
                    node["sfc_colored"] = True

                else:
                    # No rule matched
                    # If fallback_random is on and not yet colored, do a one-time random
                    if prefs.fallback_random and not node.get("sfc_colored", False):
                        col = (
                            random.random(),
                            random.random(),
                            random.random()
                        )
                        apply_color_to_frame(node, col)
                        node["sfc_colored"] = True
                    # else: leave existing color intact (do not clear tag)

                continue

_registered_handlers = []

def register_handlers():
    # 1) Depsgraph handler
    if on_node_tree_update not in _registered_handlers:
        bpy.app.handlers.depsgraph_update_post.append(on_node_tree_update)
        _registered_handlers.append(on_node_tree_update)

    # 2) Timer callback (no membership check)
    # Always register; Blender ensures no duplicate
    bpy.app.timers.register(_frame_color_timer)

def unregister_handlers():
    # 1) Remove depsgraph handlers
    for h in _registered_handlers:
        if h in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(h)
    _registered_handlers.clear()

    # 2) Unregister the timer callback
    try:
        bpy.app.timers.unregister(_frame_color_timer)
    except Exception:
        pass