# logic.py – rule resolution and color assignment

import bpy


def apply_color_to_frame(frame, color):
    if frame:
        frame.use_custom_color = True
        frame.color = color[:3]  # Blender uses RGB only for frame


def get_nodes_in_frame(frame, node_tree):
    return [n for n in node_tree.nodes if n.parent == frame]


def assign_color_to_frame(prefs, frame, node_tree):
    label = frame.label
    nodes = get_nodes_in_frame(frame, node_tree)

    # First: check node-based rules
    for node in nodes:
        rule = storage.find_node_rule(prefs, node.bl_idname)
        if rule:
            color = resolve_rule_color(prefs, rule, hash(node.name))
            apply_color_to_frame(frame, color)
            return

    # Second: check keyword rules
    rule = storage.find_keyword_rule(prefs, label)
    if rule:
        color = resolve_rule_color(prefs, rule, hash(label))
        apply_color_to_frame(frame, color)
        return

    # Fallback color
    apply_color_to_frame(frame, (0.3, 0.3, 0.3))


def resolve_rule_color(prefs, rule, seed_index):
    if rule.mode == 'SINGLE':
        return rule.color
    else:
        palette = storage.get_palette_by_name(prefs, rule.palette_name)
        return storage.get_color_from_palette(palette, seed_index)