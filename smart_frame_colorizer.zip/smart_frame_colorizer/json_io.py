import os
import json
import bpy


def export_config(path: str, prefs: bpy.types.AddonPreferences):
    """
    Write out prefs.palettes, prefs.node_rules, and prefs.keyword_rules
    into a JSON file at `path`.
    """
    data = {
        "palettes": [],
        "node_rules": [],
        "keyword_rules": []
    }

    # ───────────────────────────────────────────────────────────────
    # 1) Palettes
    # ───────────────────────────────────────────────────────────────
    for p in prefs.palettes:
        # Each palette: name + list of 3‐tuples (R,G,B)
        pdata = {
            "name": p.name,
            "colors": [tuple(c.color) for c in p.colors]
        }
        data["palettes"].append(pdata)

    # ───────────────────────────────────────────────────────────────
    # 2) Node‐Based Rules
    # ───────────────────────────────────────────────────────────────
    for nr in prefs.node_rules:
        nrdata = {
            "node_type": nr.node_type,
            "mode": nr.mode
        }
        if nr.mode == "SINGLE":
            nrdata["color"] = tuple(nr.color)
        else:
            nrdata["palette_name"] = nr.palette_name
        data["node_rules"].append(nrdata)

    # ───────────────────────────────────────────────────────────────
    # 3) Keyword‐Based Rules
    # ───────────────────────────────────────────────────────────────
    for kr in prefs.keyword_rules:
        krdata = {
            "label": kr.label,
            "mode": kr.mode
        }
        if kr.mode == "SINGLE":
            krdata["color"] = tuple(kr.color)
        else:
            krdata["palette_name"] = kr.palette_name
        data["keyword_rules"].append(krdata)

    # ───────────────────────────────────────────────────────────────
    # 4) Ensure directory exists, then write JSON
    # ───────────────────────────────────────────────────────────────
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=4)


def import_config(path: str, prefs: bpy.types.AddonPreferences):
    """
    Read JSON from `path` and populate prefs.palettes, prefs.node_rules,
    and prefs.keyword_rules`. Any existing collections will be cleared first.
    Raises an exception on failure.
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(f"JSON file not found: {path}")

    with open(path, "r") as f:
        data = json.load(f)

    # ───────────────────────────────────────────────────────────────
    # 1) Clear existing data
    # ───────────────────────────────────────────────────────────────
    prefs.palettes.clear()
    prefs.node_rules.clear()
    prefs.keyword_rules.clear()

    # ───────────────────────────────────────────────────────────────
    # 2) Load Palettes
    # ───────────────────────────────────────────────────────────────
    for p_data in data.get("palettes", []):
        p = prefs.palettes.add()
        p.name = p_data.get("name", "Palette")
        for color_triplet in p_data.get("colors", []):
            c = p.colors.add()
            # Ensure it’s a 3‐tuple of floats
            if len(color_triplet) == 3:
                c.color = (
                    float(color_triplet[0]),
                    float(color_triplet[1]),
                    float(color_triplet[2])
                )
            else:
                # If somehow not 3 floats, default to white
                c.color = (1.0, 1.0, 1.0)

    # ───────────────────────────────────────────────────────────────
    # 3) Load Node‐Based Rules
    # ───────────────────────────────────────────────────────────────
    for nr_data in data.get("node_rules", []):
        nr = prefs.node_rules.add()
        nr.node_type = nr_data.get("node_type", "")
        nr.mode = nr_data.get("mode", "SINGLE")
        if nr.mode == "SINGLE":
            col = nr_data.get("color", (0.5, 0.5, 0.5))
            if len(col) == 3:
                nr.color = (float(col[0]), float(col[1]), float(col[2]))
            else:
                nr.color = (0.5, 0.5, 0.5)
        else:
            nr.palette_name = nr_data.get("palette_name", "")

    # ───────────────────────────────────────────────────────────────
    # 4) Load Keyword‐Based Rules
    # ───────────────────────────────────────────────────────────────
    for kr_data in data.get("keyword_rules", []):
        kr = prefs.keyword_rules.add()
        kr.label = kr_data.get("label", "")
        kr.mode = kr_data.get("mode", "SINGLE")
        if kr.mode == "SINGLE":
            col = kr_data.get("color", (0.5, 0.5, 0.5))
            if len(col) == 3:
                kr.color = (float(col[0]), float(col[1]), float(col[2]))
            else:
                kr.color = (0.5, 0.5, 0.5)
        else:
            kr.palette_name = kr_data.get("palette_name", "")