bl_info = {
    "name":        "Smart Frame Colorizer",
    "author":      "BlenPY",
    "version":     (0, 0, 9),
    "blender":     (4, 4, 0),
    "description": "Automatically color frame nodes in the Shader Editor based on rules or randomly.",
    "category":    "Node",
}

# Import all sub-modules so Blender can register them
from . import (
    preferences,
    operators,
    json_io,
    logic,
    storage,
    ui,      
)

import bpy

modules = (
    preferences,
    operators,
    json_io,
    logic,
    storage,
    ui,
)

def register():
    # 1) Register all modules in turn
    for mod in modules:
        if hasattr(mod, "register"):
            mod.register()

    # 2) After registration, start our depsgraph handler for frame‐coloring
    logic.register_handlers()

def unregister():
    # 1) Remove our depsgraph handler so we stop coloring
    logic.unregister_handlers()

    # 2) Unregister everything in reverse order
    for mod in reversed(modules):
        if hasattr(mod, "unregister"):
            mod.unregister()